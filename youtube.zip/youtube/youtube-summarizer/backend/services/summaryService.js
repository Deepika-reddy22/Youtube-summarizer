const Summary = require('../models/Summary');
const YouTubeService = require('./youtubeService');
const AIService = require('./aiService');

class SummaryService {
  constructor(youtubeApiKey, openaiApiKey) {
    this.youtubeService = new YouTubeService(youtubeApiKey);
    this.aiService = new AIService(openaiApiKey);
  }

  // YouTube URL validation and extraction function (same as in controller)
  extractVideoId(url) {
    if (!url || typeof url !== 'string') return null;
    
    try {
      // Trim and clean the URL
      const cleanUrl = url.trim();
      
      // Check for youtu.be short URLs
      if (cleanUrl.includes('youtu.be/')) {
        const match = cleanUrl.match(/youtu\.be\/([^&?#]+)/);
        return match ? match[1] : null;
      }
      
      // Check for youtube.com URLs
      if (cleanUrl.includes('youtube.com')) {
        const urlObj = new URL(cleanUrl);
        const videoId = urlObj.searchParams.get('v');
        return videoId || null;
      }
      
      // Check if it's just a video ID (11 characters)
      if (cleanUrl.match(/^[a-zA-Z0-9_-]{11}$/)) {
        return cleanUrl;
      }
      
      return null;
    } catch (error) {
      console.error('Error extracting video ID:', error);
      return null;
    }
  }

  async createSummary(userId, videoUrl, options = {}) {
    const startTime = Date.now();

    try {
      // Validate YouTube URL before processing
      const videoId = this.extractVideoId(videoUrl);
      if (!videoId) {
        throw new Error('Invalid YouTube URL. Please provide a valid YouTube video URL.');
      }

      // Step 1: Get video information using the validated videoId
      const videoInfo = await this.youtubeService.getVideoInfo(videoId);
      
      if (!videoInfo || !videoInfo.title) {
        throw new Error('Video not found or unavailable. Please check the YouTube URL.');
      }

      // Step 2: Get transcript (simplified - using description as fallback)
      let transcript;
      try {
        transcript = await this.youtubeService.getTranscript(videoId);
      } catch (transcriptError) {
        console.log('Transcript not available, using description as fallback');
        transcript = videoInfo.description || "Content based on video metadata.";
      }

      // Step 3: Generate summary using AI
      const summaryText = await this.aiService.generateSummary(transcript, options);

      if (!summaryText || summaryText.trim().length === 0) {
        throw new Error('Failed to generate summary. Please try again.');
      }

      // Step 4: Analyze summary (make these optional to avoid API failures)
      let sentiment = { score: 0, label: 'neutral' };
      let keyPoints = [];

      try {
        sentiment = await this.aiService.analyzeSentiment(summaryText);
      } catch (sentimentError) {
        console.warn('Sentiment analysis failed, using default:', sentimentError.message);
      }

      try {
        keyPoints = await this.aiService.extractKeyPoints(summaryText);
      } catch (keyPointsError) {
        console.warn('Key points extraction failed:', keyPointsError.message);
        // Generate basic key points from summary
        keyPoints = this.generateFallbackKeyPoints(summaryText);
      }

      const processingTime = Math.round((Date.now() - startTime) / 1000);

      // Step 5: Calculate analytics
      const analytics = {
        wordCount: summaryText.split(/\s+/).length,
        readingTime: Math.ceil(summaryText.split(/\s+/).length / 200), // 200 words per minute
        readabilityScore: this.calculateReadability(summaryText),
        keyPoints,
        sentiment,
        transcriptLength: transcript.length
      };

      // Step 6: Save to database
      const summary = await Summary.create({
        user: userId,
        videoInfo: {
          ...videoInfo,
          videoId: videoId // Ensure videoId is stored
        },
        summary: summaryText,
        options,
        analytics,
        processingTime,
        duration: videoInfo.duration || 0
      });

      return summary;
    } catch (error) {
      console.error('Summary Service Error:', error);
      
      // Re-throw with more user-friendly messages for known errors
      if (error.message.includes('quota exceeded') || error.message.includes('API key')) {
        throw new Error('YouTube API quota exceeded. Please try again later.');
      }
      
      if (error.message.includes('not found') || error.message.includes('unavailable')) {
        throw new Error('Video not found or unavailable. Please check the YouTube URL.');
      }
      
      if (error.message.includes('transcript') || error.message.includes('subtitles')) {
        throw new Error('No transcript available for this video. Please try a different video.');
      }
      
      throw error;
    }
  }

  generateFallbackKeyPoints(summaryText) {
    // Simple fallback key points generation from summary sentences
    const sentences = summaryText.split(/[.!?]+/).filter(s => s.trim().length > 10);
    return sentences.slice(0, 5).map((sentence, index) => ({
      point: sentence.trim(),
      timestamp: null,
      importance: 5 - index // First points are more important
    }));
  }

  calculateReadability(text) {
    if (!text || text.length === 0) return 0;

    try {
      const words = text.split(/\s+/).length;
      const sentences = text.split(/[.!?]+/).length;
      const syllables = this.countSyllables(text);

      if (words === 0 || sentences === 0) return 50; // Default score

      const score = 206.835 - 1.015 * (words / sentences) - 84.6 * (syllables / words);
      return Math.max(0, Math.min(100, Math.round(score)));
    } catch (error) {
      console.warn('Readability calculation failed:', error);
      return 50; // Default score on error
    }
  }

  countSyllables(text) {
    if (!text) return 0;
    
    return text.toLowerCase()
      .split(/\s+/)
      .reduce((count, word) => {
        // Simple syllable estimation: average 1 syllable per 3 characters
        return count + Math.max(1, Math.floor(word.replace(/[^a-z]/g, '').length / 3));
      }, 0);
  }

  async getUserSummaries(userId, page = 1, limit = 10, filters = {}) {
    try {
      const skip = (page - 1) * limit;
      
      const query = { user: userId };
      
      if (filters.isFavorite) {
        query.isFavorite = true;
      }
      
      if (filters.search && filters.search.trim()) {
        const searchRegex = { $regex: filters.search.trim(), $options: 'i' };
        query.$or = [
          { 'videoInfo.title': searchRegex },
          { 'videoInfo.channel': searchRegex },
          { 'summary': searchRegex },
          { tags: searchRegex }
        ];
      }

      const summaries = await Summary.find(query)
        .select('-__v') // Exclude version key
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit);

      const total = await Summary.countDocuments(query);

      return {
        summaries,
        pagination: {
          page,
          limit,
          total,
          pages: Math.ceil(total / limit),
          hasNext: page < Math.ceil(total / limit),
          hasPrev: page > 1
        }
      };
    } catch (error) {
      console.error('Get user summaries error:', error);
      throw new Error('Failed to fetch summaries');
    }
  }

  // Additional utility method to check if video can be summarized
  async validateVideo(videoUrl) {
    try {
      const videoId = this.extractVideoId(videoUrl);
      if (!videoId) {
        return { isValid: false, error: 'Invalid YouTube URL format' };
      }

      const videoInfo = await this.youtubeService.getVideoInfo(videoId);
      if (!videoInfo) {
        return { isValid: false, error: 'Video not found' };
      }

      // Check if video is accessible and not private/restricted
      if (videoInfo.status !== 'active') {
        return { isValid: false, error: 'Video is private or restricted' };
      }

      return { 
        isValid: true, 
        videoId, 
        videoTitle: videoInfo.title,
        channel: videoInfo.channel,
        duration: videoInfo.duration
      };
    } catch (error) {
      return { isValid: false, error: error.message };
    }
  }
}

module.exports = SummaryService;