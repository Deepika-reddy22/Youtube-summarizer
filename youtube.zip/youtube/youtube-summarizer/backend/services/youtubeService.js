import axios from 'axios';

class YouTubeService {
  constructor(apiKey) {
    this.apiKey = apiKey;
    this.baseURL = 'https://www.googleapis.com/youtube/v3';
  }

  // Keep this method for backward compatibility, but it's now mainly used internally
  extractVideoId(url) {
    if (!url || typeof url !== 'string') return null;
    
    try {
      // If it's already a video ID (11 characters), return it directly
      if (url.match(/^[a-zA-Z0-9_-]{11}$/)) {
        return url;
      }
      
      const regex = /(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/;
      const match = url.match(regex);
      return match ? match[1] : null;
    } catch (error) {
      return null;
    }
  }

  async getVideoInfo(videoUrlOrId) {
    try {
      // Extract video ID from URL or use directly if it's already an ID
      const videoId = this.extractVideoId(videoUrlOrId);
      
      if (!videoId) {
        throw new Error('Invalid YouTube video ID or URL');
      }

      const response = await axios.get(`${this.baseURL}/videos`, {
        params: {
          part: 'snippet,contentDetails,statistics',
          id: videoId,
          key: this.apiKey
        }
      });

      if (!response.data.items || response.data.items.length === 0) {
        throw new Error('Video not found');
      }

      const video = response.data.items[0];
      
      // Calculate duration in seconds for analytics
      const durationInSeconds = this.parseDurationToSeconds(video.contentDetails.duration);
      
      return {
        videoId,
        title: video.snippet.title,
        channel: video.snippet.channelTitle,
        description: video.snippet.description,
        thumbnail: video.snippet.thumbnails.maxres?.url || video.snippet.thumbnails.high?.url || video.snippet.thumbnails.default?.url,
        duration: this.formatDuration(video.contentDetails.duration),
        durationInSeconds: durationInSeconds,
        views: parseInt(video.statistics.viewCount) || 0,
        likes: parseInt(video.statistics.likeCount) || 0,
        comments: parseInt(video.statistics.commentCount) || 0,
        publishedAt: video.snippet.publishedAt,
        tags: video.snippet.tags || [],
        categoryId: video.snippet.categoryId
      };
    } catch (error) {
      console.error('YouTube API Error:', error.message);
      
      if (error.response?.status === 403) {
        throw new Error('YouTube API quota exceeded. Please try again later.');
      }
      
      if (error.response?.status === 404) {
        throw new Error('Video not found or unavailable.');
      }
      
      throw new Error('Failed to fetch video information from YouTube');
    }
  }

  parseDurationToSeconds(duration) {
    try {
      const match = duration.match(/PT(\d+H)?(\d+M)?(\d+S)?/);
      const hours = parseInt(match[1]) || 0;
      const minutes = parseInt(match[2]) || 0;
      const seconds = parseInt(match[3]) || 0;
      return hours * 3600 + minutes * 60 + seconds;
    } catch (error) {
      return 0;
    }
  }

  formatDuration(duration) {
    try {
      const seconds = this.parseDurationToSeconds(duration);
      const hours = Math.floor(seconds / 3600);
      const minutes = Math.floor((seconds % 3600) / 60);
      const secs = seconds % 60;

      if (hours > 0) {
        return `${hours}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
      } else {
        return `${minutes}:${secs.toString().padStart(2, '0')}`;
      }
    } catch (error) {
      return '0:00';
    }
  }

  async getTranscript(videoId) {
    try {
      // For now, return a placeholder or use description
      // In a real implementation, you would use:
      // - YouTube's transcript API
      // - A third-party service
      // - Fallback to audio processing
      
      console.log('Transcript extraction not fully implemented for video:', videoId);
      return null;
      
      // Example of what a real implementation might look like:
      /*
      const response = await axios.get(`${this.baseURL}/captions`, {
        params: {
          part: 'snippet',
          videoId: videoId,
          key: this.apiKey
        }
      });
      
      // Process captions and return transcript
      return processedTranscript;
      */
    } catch (error) {
      console.warn('Transcript extraction failed:', error.message);
      return null; // Return null so summary service can use fallback
    }
  }

  // Additional method to search videos
  async searchVideos(query, maxResults = 5) {
    try {
      const response = await axios.get(`${this.baseURL}/search`, {
        params: {
          part: 'snippet',
          q: query,
          type: 'video',
          maxResults: maxResults,
          key: this.apiKey
        }
      });

      return response.data.items.map(item => ({
        videoId: item.id.videoId,
        title: item.snippet.title,
        channel: item.snippet.channelTitle,
        description: item.snippet.description,
        thumbnail: item.snippet.thumbnails.high?.url,
        publishedAt: item.snippet.publishedAt
      }));
    } catch (error) {
      console.error('YouTube Search Error:', error.message);
      throw new Error('Failed to search videos');
    }
  }

  // Method to check if API key is working
  async testConnection() {
    try {
      const response = await axios.get(`${this.baseURL}/videos`, {
        params: {
          part: 'snippet',
          id: 'dQw4w9WgXcQ', // Test with a known video
          key: this.apiKey
        }
      });
      return response.data.items.length > 0;
    } catch (error) {
      console.error('YouTube API Connection Test Failed:', error.message);
      return false;
    }
  }
}

export default YouTubeService;