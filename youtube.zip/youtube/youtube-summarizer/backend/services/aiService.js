import axios from 'axios';

class AIService {
  constructor(apiKey) {
    this.apiKey = apiKey;
    this.baseURL = 'https://api.openai.com/v1';
  }

  async generateSummary(transcript, options = {}) {
    const {
      language = 'english',
      length = 'medium',
      format = 'paragraph',
      tone = 'professional',
      focusAreas = [],
      customInstructions = ''
    } = options;

    try {
      const prompt = this.buildPrompt(transcript, {
        language,
        length,
        format,
        tone,
        focusAreas,
        customInstructions
      });

      const response = await axios.post(`${this.baseURL}/chat/completions`, {
        model: 'gpt-4',
        messages: [
          {
            role: 'system',
            content: 'You are a helpful assistant that creates concise, accurate summaries of YouTube videos.'
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        max_tokens: length === 'short' ? 500 : length === 'medium' ? 1000 : 2000,
        temperature: 0.7
      }, {
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json'
        }
      });

      return response.data.choices[0].message.content;
    } catch (error) {
      console.error('AI Service Error:', error.response?.data || error.message);
      throw new Error('Failed to generate summary');
    }
  }

  buildPrompt(transcript, options) {
    const {
      language,
      length,
      format,
      tone,
      focusAreas,
      customInstructions
    } = options;

    let prompt = `Please create a ${length} summary of the following YouTube video transcript in ${language}. `;
    prompt += `Use a ${tone} tone and format the summary as ${format}. `;

    if (focusAreas.length > 0) {
      prompt += `Focus on these areas: ${focusAreas.join(', ')}. `;
    }

    if (customInstructions) {
      prompt += `Additional instructions: ${customInstructions}. `;
    }

    prompt += `\n\nTranscript:\n${transcript}\n\nSummary:`;

    return prompt;
  }

  async analyzeSentiment(text) {
    try {
      const response = await axios.post(`${this.baseURL}/chat/completions`, {
        model: 'gpt-3.5-turbo',
        messages: [
          {
            role: 'system',
            content: 'Analyze the sentiment of the following text and respond with only one word: positive, negative, or neutral.'
          },
          {
            role: 'user',
            content: text
          }
        ],
        max_tokens: 10,
        temperature: 0.3
      }, {
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json'
        }
      });

      return response.data.choices[0].message.content.toLowerCase().trim();
    } catch (error) {
      console.error('Sentiment Analysis Error:', error);
      return 'neutral';
    }
  }
}

export default AIService;