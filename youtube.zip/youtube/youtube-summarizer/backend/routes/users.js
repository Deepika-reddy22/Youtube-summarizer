const express = require('express');
const {
  getProfile,
  updateProfile,
  deleteAccount
} = require('../controllers/userController');
const { protect } = require