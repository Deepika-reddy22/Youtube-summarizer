const express = require('express');
const {
  createSummary,
  getSummaries,
  getSummary,
  updateSummary,
  deleteSummary,
  getStats
} = require('../controllers/summaryController');
const { protect } = require('../middleware/auth');

const router = express.Router();

router.use(protect);

router.route('/')
  .post(createSummary)
  .get(getSummaries);

router.route('/stats')
  .get(getStats);

router.route('/:id')
  .get(getSummary)
  .put(updateSummary)
  .delete(deleteSummary);

module.exports = router;