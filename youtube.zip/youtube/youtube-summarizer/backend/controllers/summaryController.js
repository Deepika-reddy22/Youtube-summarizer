const Summary = require('../models/Summary');
const SummaryService = require('../services/summaryService');
const User = require('../models/User');

const summaryService = new SummaryService(
  process.env.YOUTUBE_API_KEY,
  process.env.OPENAI_API_KEY
);

// YouTube URL validation and extraction function
function extractVideoId(url) {
  if (!url || typeof url !== 'string') return null;
  
  try {
    // Trim and clean the URL
    const cleanUrl = url.trim();
    
    // Regular expression to match YouTube video IDs in various formats
    const patterns = [
      /(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([^&?#]+)/,
      /^([a-zA-Z0-9_-]{11})$/
    ];
    
    // Check for youtu.be short URLs
    if (cleanUrl.includes('youtu.be/')) {
      const match = cleanUrl.match(/youtu\.be\/([^&?#]+)/);
      return match ? match[1] : null;
    }
    
    // Check for youtube.com URLs
    if (cleanUrl.includes('youtube.com')) {
      // Handle both http and https
      const urlObj = new URL(cleanUrl);
      const videoId = urlObj.searchParams.get('v');
      return videoId || null;
    }
    
    // Check if it's just a video ID (11 characters)
    if (cleanUrl.match(/^[a-zA-Z0-9_-]{11}$/)) {
      return cleanUrl;
    }
    
    // Try all patterns as fallback
    for (const pattern of patterns) {
      const match = cleanUrl.match(pattern);
      if (match && match[1]) {
        return match[1];
      }
    }
    
    return null;
  } catch (error) {
    console.error('Error extracting video ID:', error);
    return null;
  }
}

// Validate YouTube URL format
function validateYouTubeUrl(url) {
  if (!url) return false;
  
  const videoId = extractVideoId(url);
  if (!videoId) return false;
  
  // YouTube video IDs are always 11 characters
  return videoId.length === 11;
}

// @desc    Create a new summary
// @route   POST /api/summaries
// @access  Private
exports.createSummary = async (req, res) => {
  try {
    const { videoUrl, options = {} } = req.body;

    // Validate input
    if (!videoUrl || typeof videoUrl !== 'string') {
      return res.status(400).json({
        success: false,
        message: 'Please provide a valid YouTube URL'
      });
    }

    // Validate YouTube URL format
    if (!validateYouTubeUrl(videoUrl)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid YouTube URL. Please provide a valid YouTube video URL in one of these formats:\n' +
                 '- https://www.youtube.com/watch?v=VIDEO_ID\n' +
                 '- https://youtu.be/VIDEO_ID\n' +
                 '- https://www.youtube.com/embed/VIDEO_ID'
      });
    }

    // Extract video ID for additional validation
    const videoId = extractVideoId(videoUrl);
    
    // Check user's subscription limits
    const user = await User.findById(req.user.id);
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    if (user.subscription.plan === 'free' && user.usage.totalSummaries >= 50) {
      return res.status(403).json({
        success: false,
        message: 'Free plan limit reached. Upgrade to create more summaries.'
      });
    }

    // Create summary using the service
    const summary = await summaryService.createSummary(req.user.id, videoUrl, options);

    // Update user usage
    await User.findByIdAndUpdate(req.user.id, {
      $inc: { 
        'usage.totalSummaries': 1, 
        'usage.totalTimeSaved': options.summaryLength === 'long' ? 15 : 10 
      },
      'usage.lastSummaryDate': new Date()
    });

    res.status(201).json({
      success: true,
      data: summary,
      message: 'Summary created successfully'
    });

  } catch (error) {
    console.error('Create summary error:', error);
    
    // Handle specific error types
    if (error.message.includes('YouTube API') || error.message.includes('video not found')) {
      return res.status(404).json({
        success: false,
        message: 'Video not found or unavailable. Please check the YouTube URL.'
      });
    }
    
    if (error.message.includes('quota') || error.message.includes('API key')) {
      return res.status(429).json({
        success: false,
        message: 'Service temporarily unavailable. Please try again later.'
      });
    }

    res.status(400).json({
      success: false,
      message: error.message || 'Failed to create summary'
    });
  }
};

// @desc    Get all summaries for user
// @route   GET /api/summaries
// @access  Private
exports.getSummaries = async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const search = req.query.search || '';
    const isFavorite = req.query.favorite === 'true';

    // Validate pagination parameters
    if (page < 1 || limit < 1 || limit > 100) {
      return res.status(400).json({
        success: false,
        message: 'Invalid pagination parameters'
      });
    }

    const filters = {};
    if (search) {
      filters.search = search.trim();
    }
    if (isFavorite) {
      filters.isFavorite = true;
    }

    const result = await summaryService.getUserSummaries(
      req.user.id,
      page,
      limit,
      filters
    );

    res.json({
      success: true,
      ...result
    });

  } catch (error) {
    console.error('Get summaries error:', error);
    res.status(400).json({
      success: false,
      message: error.message || 'Failed to fetch summaries'
    });
  }
};

// @desc    Get single summary
// @route   GET /api/summaries/:id
// @access  Private
exports.getSummary = async (req, res) => {
  try {
    const { id } = req.params;

    // Validate ID format
    if (!id || id.length !== 24) {
      return res.status(400).json({
        success: false,
        message: 'Invalid summary ID format'
      });
    }

    const summary = await Summary.findOne({
      _id: id,
      user: req.user.id
    }).populate('user', 'name email');

    if (!summary) {
      return res.status(404).json({
        success: false,
        message: 'Summary not found'
      });
    }

    res.json({
      success: true,
      data: summary
    });

  } catch (error) {
    console.error('Get summary error:', error);
    res.status(400).json({
      success: false,
      message: error.message || 'Failed to fetch summary'
    });
  }
};

// @desc    Update summary (favorite, tags, etc.)
// @route   PUT /api/summaries/:id
// @access  Private
exports.updateSummary = async (req, res) => {
  try {
    const { id } = req.params;
    const updateData = req.body;

    // Validate ID format
    if (!id || id.length !== 24) {
      return res.status(400).json({
        success: false,
        message: 'Invalid summary ID format'
      });
    }

    // Allowed fields for update
    const allowedFields = ['isFavorite', 'tags', 'title', 'notes'];
    const filteredData = {};
    
    Object.keys(updateData).forEach(key => {
      if (allowedFields.includes(key)) {
        filteredData[key] = updateData[key];
      }
    });

    // Check if there's anything to update
    if (Object.keys(filteredData).length === 0) {
      return res.status(400).json({
        success: false,
        message: 'No valid fields to update'
      });
    }

    const summary = await Summary.findOneAndUpdate(
      { _id: id, user: req.user.id },
      filteredData,
      { 
        new: true, 
        runValidators: true,
        fields: { __v: 0 } // Exclude version key
      }
    );

    if (!summary) {
      return res.status(404).json({
        success: false,
        message: 'Summary not found'
      });
    }

    res.json({
      success: true,
      data: summary,
      message: 'Summary updated successfully'
    });

  } catch (error) {
    console.error('Update summary error:', error);
    res.status(400).json({
      success: false,
      message: error.message || 'Failed to update summary'
    });
  }
};

// @desc    Delete summary
// @route   DELETE /api/summaries/:id
// @access  Private
exports.deleteSummary = async (req, res) => {
  try {
    const { id } = req.params;

    // Validate ID format
    if (!id || id.length !== 24) {
      return res.status(400).json({
        success: false,
        message: 'Invalid summary ID format'
      });
    }

    const summary = await Summary.findOneAndDelete({
      _id: id,
      user: req.user.id
    });

    if (!summary) {
      return res.status(404).json({
        success: false,
        message: 'Summary not found'
      });
    }

    // Update user usage (don't go below 0)
    await User.findByIdAndUpdate(req.user.id, {
      $inc: { 
        'usage.totalSummaries': -1,
        'usage.totalTimeSaved': -10 
      }
    });

    res.json({
      success: true,
      message: 'Summary deleted successfully',
      deletedId: id
    });

  } catch (error) {
    console.error('Delete summary error:', error);
    res.status(400).json({
      success: false,
      message: error.message || 'Failed to delete summary'
    });
  }
};

// @desc    Get user statistics
// @route   GET /api/summaries/stats
// @access  Private
exports.getStats = async (req, res) => {
  try {
    const totalSummaries = await Summary.countDocuments({ user: req.user.id });
    const favoriteSummaries = await Summary.countDocuments({ 
      user: req.user.id, 
      isFavorite: true 
    });
    
    const recentSummaries = await Summary.find({ user: req.user.id })
      .sort({ createdAt: -1 })
      .limit(5)
      .select('videoInfo.title createdAt duration');

    // Get summary count by month for charts
    const monthlyStats = await Summary.aggregate([
      {
        $match: { user: req.user._id }
      },
      {
        $group: {
          _id: {
            year: { $year: '$createdAt' },
            month: { $month: '$createdAt' }
          },
          count: { $sum: 1 }
        }
      },
      {
        $sort: { '_id.year': 1, '_id.month': 1 }
      },
      {
        $limit: 6
      }
    ]);

    // Calculate total time saved (adjust based on summary length if available)
    const totalDuration = await Summary.aggregate([
      {
        $match: { user: req.user._id }
      },
      {
        $group: {
          _id: null,
          totalDuration: { $sum: '$duration' }
        }
      }
    ]);

    const totalTimeSaved = totalDuration.length > 0 ? 
      Math.round(totalDuration[0].totalDuration / 60) : // Convert seconds to minutes
      totalSummaries * 10; // Fallback calculation

    res.json({
      success: true,
      data: {
        totalSummaries,
        favoriteSummaries,
        totalTimeSaved,
        recentSummaries,
        monthlyStats
      }
    });

  } catch (error) {
    console.error('Get stats error:', error);
    res.status(400).json({
      success: false,
      message: error.message || 'Failed to fetch statistics'
    });
  }
};

// @desc    Validate YouTube URL (utility endpoint)
// @route   POST /api/summaries/validate-url
// @access  Private
exports.validateYouTubeUrl = async (req, res) => {
  try {
    const { videoUrl } = req.body;

    if (!videoUrl) {
      return res.status(400).json({
        success: false,
        message: 'Please provide a YouTube URL'
      });
    }

    const isValid = validateYouTubeUrl(videoUrl);
    const videoId = extractVideoId(videoUrl);

    res.json({
      success: true,
      data: {
        isValid,
        videoId: isValid ? videoId : null,
        supportedFormats: [
          'https://www.youtube.com/watch?v=VIDEO_ID',
          'https://youtu.be/VIDEO_ID',
          'https://www.youtube.com/embed/VIDEO_ID'
        ]
      }
    });

  } catch (error) {
    console.error('Validate URL error:', error);
    res.status(400).json({
      success: false,
      message: error.message || 'Failed to validate URL'
    });
  }
};

// Export utility functions for testing
exports._testFunctions = {
  extractVideoId,
  validateYouTubeUrl
};