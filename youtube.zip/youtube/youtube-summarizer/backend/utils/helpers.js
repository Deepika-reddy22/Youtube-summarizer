const crypto = require('crypto');

/**
 * Generate a random token
 * @param {number} length - Token length
 * @returns {string} Random token
 */
exports.generateRandomToken = (length = 32) => {
  return crypto.randomBytes(length).toString('hex');
};

/**
 * Generate a unique share token for summaries
 * @returns {string} Share token
 */
exports.generateShareToken = () => {
  return `st_${Date.now()}_${crypto.randomBytes(8).toString('hex')}`;
};

/**
 * Calculate reading time for text
 * @param {string} text - Text to calculate reading time for
 * @param {number} wordsPerMinute - Reading speed (default: 200)
 * @returns {number} Reading time in minutes
 */
exports.calculateReadingTime = (text, wordsPerMinute = 200) => {
  const words = text.split(/\s+/).length;
  return Math.ceil(words / wordsPerMinute);
};

/**
 * Calculate word count
 * @param {string} text - Text to count words
 * @returns {number} Word count
 */
exports.countWords = (text) => {
  return text.split(/\s+/).filter(word => word.length > 0).length;
};

/**
 * Format duration from seconds to HH:MM:SS
 * @param {number} seconds - Duration in seconds
 * @returns {string} Formatted duration
 */
exports.formatDuration = (seconds) => {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = seconds % 60;

  if (hours > 0) {
    return `${hours}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  }
  return `${minutes}:${secs.toString().padStart(2, '0')}`;
};

/**
 * Sanitize YouTube URL
 * @param {string} url - YouTube URL
 * @returns {string} Sanitized URL
 */
exports.sanitizeYouTubeUrl = (url) => {
  try {
    const urlObj = new URL(url);
    
    // Keep only essential parameters
    const videoId = urlObj.searchParams.get('v');
    if (videoId) {
      return `https://www.youtube.com/watch?v=${videoId}`;
    }
    
    // Handle youtu.be links
    if (urlObj.hostname === 'youtu.be') {
      const videoId = urlObj.pathname.slice(1);
      return `https://www.youtube.com/watch?v=${videoId}`;
    }
    
    return url;
  } catch (error) {
    return url;
  }
};

/**
 * Validate YouTube URL
 * @param {string} url - YouTube URL to validate
 * @returns {boolean} Whether URL is valid
 */
exports.isValidYouTubeUrl = (url) => {
  const patterns = [
    /^(https?:\/\/)?(www\.)?(youtube\.com\/watch\?v=)([a-zA-Z0-9_-]{11})/,
    /^(https?:\/\/)?(www\.)?(youtu\.be\/)([a-zA-Z0-9_-]{11})/,
    /^(https?:\/\/)?(www\.)?(youtube\.com\/embed\/)([a-zA-Z0-9_-]{11})/
  ];
  
  return patterns.some(pattern => pattern.test(url));
};

/**
 * Extract video ID from YouTube URL
 * @param {string} url - YouTube URL
 * @returns {string|null} Video ID or null
 */
exports.extractVideoId = (url) => {
  const patterns = [
    /(?:youtube\.com\/watch\?v=)([a-zA-Z0-9_-]{11})/,
    /(?:youtu\.be\/)([a-zA-Z0-9_-]{11})/,
    /(?:youtube\.com\/embed\/)([a-zA-Z0-9_-]{11})/
  ];
  
  for (const pattern of patterns) {
    const match = url.match(pattern);
    if (match) {
      return match[1];
    }
  }
  
  return null;
};

/**
 * Generate pagination metadata
 * @param {number} page - Current page
 * @param {number} limit - Items per page
 * @param {number} total - Total items
 * @returns {Object} Pagination metadata
 */
exports.generatePagination = (page, limit, total) => {
  const pages = Math.ceil(total / limit);
  const hasNext = page < pages;
  const hasPrev = page > 1;
  
  return {
    page,
    limit,
    total,
    pages,
    hasNext,
    hasPrev,
    nextPage: hasNext ? page + 1 : null,
    prevPage: hasPrev ? page - 1 : null
  };
};

/**
 * Format API response
 * @param {boolean} success - Success status
 * @param {string} message - Response message
 * @param {*} data - Response data
 * @param {Object} meta - Metadata (pagination, etc.)
 * @returns {Object} Formatted response
 */
exports.formatResponse = (success, message, data = null, meta = null) => {
  const response = {
    success,
    message,
    timestamp: new Date().toISOString()
  };
  
  if (data !== null) {
    response.data = data;
  }
  
  if (meta !== null) {
    response.meta = meta;
  }
  
  return response;
};

/**
 * Calculate time saved (estimate based on video duration)
 * @param {string} duration - Video duration (HH:MM:SS or MM:SS)
 * @returns {number} Estimated time saved in minutes
 */
exports.calculateTimeSaved = (duration) => {
  if (!duration) return 10; // Default 10 minutes
  
  try {
    const parts = duration.split(':').map(part => parseInt(part));
    let totalSeconds = 0;
    
    if (parts.length === 3) {
      // HH:MM:SS
      totalSeconds = parts[0] * 3600 + parts[1] * 60 + parts[2];
    } else if (parts.length === 2) {
      // MM:SS
      totalSeconds = parts[0] * 60 + parts[1];
    }
    
    // Assume summary saves 80% of video time, with min 2min and max 30min
    const savedSeconds = Math.min(Math.max(totalSeconds * 0.8, 120), 1800);
    return Math.round(savedSeconds / 60);
  } catch (error) {
    return 10; // Fallback to 10 minutes
  }
};

/**
 * Truncate text to specified length
 * @param {string} text - Text to truncate
 * @param {number} maxLength - Maximum length
 * @returns {string} Truncated text
 */
exports.truncateText = (text, maxLength = 100) => {
  if (text.length <= maxLength) return text;
  return text.substring(0, maxLength).trim() + '...';
};

/**
 * Generate cache key for summaries
 * @param {string} videoId - YouTube video ID
 * @param {Object} options - Summary options
 * @returns {string} Cache key
 */
exports.generateCacheKey = (videoId, options = {}) => {
  const optionsString = JSON.stringify(options);
  return `summary:${videoId}:${crypto.createHash('md5').update(optionsString).digest('hex')}`;
};

/**
 * Sleep for specified milliseconds
 * @param {number} ms - Milliseconds to sleep
 * @returns {Promise} Promise that resolves after specified time
 */
exports.sleep = (ms) => {
  return new Promise(resolve => setTimeout(resolve, ms));
};

/**
 * Validate email format
 * @param {string} email - Email to validate
 * @returns {boolean} Whether email is valid
 */
exports.isValidEmail = (email) => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

/**
 * Generate progress percentage
 * @param {number} current - Current value
 * @param {number} total - Total value
 * @returns {number} Progress percentage
 */
exports.calculateProgress = (current, total) => {
  if (total === 0) return 0;
  return Math.round((current / total) * 100);
};