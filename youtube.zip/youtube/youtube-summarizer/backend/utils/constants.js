// Application Constants
module.exports = {
  // Summary Options
  SUMMARY_LENGTHS: {
    SHORT: 'short',
    MEDIUM: 'medium',
    LONG: 'long'
  },

  SUMMARY_FORMATS: {
    PARAGRAPH: 'paragraph',
    BULLET: 'bullet',
    STRUCTURED: 'structured'
  },

  TONES: {
    PROFESSIONAL: 'professional',
    CASUAL: 'casual',
    ACADEMIC: 'academic',
    SIMPLE: 'simple',
    DETAILED: 'detailed'
  },

  LANGUAGES: {
    ENGLISH: 'english',
    SPANISH: 'spanish',
    FRENCH: 'french',
    GERMAN: 'german',
    CHINESE: 'chinese',
    HINDI: 'hindi',
    ARABIC: 'arabic',
    PORTUGUESE: 'portuguese',
    RUSSIAN: 'russian',
    JAPANESE: 'japanese'
  },

  // Focus Areas
  FOCUS_AREAS: [
    'Key Concepts',
    'Step-by-Step Instructions',
    'Main Arguments',
    'Technical Details',
    'Practical Applications',
    'Critical Analysis',
    'Beginner Friendly',
    'Advanced Insights'
  ],

  // Subscription Plans
  SUBSCRIPTION_PLANS: {
    FREE: 'free',
    PRO: 'pro',
    ENTERPRISE: 'enterprise'
  },

  // Subscription Limits
  SUBSCRIPTION_LIMITS: {
    FREE: {
      summaries: 50,
      batchProcessing: false,
      customInstructions: true,
      exportFormats: true,
      apiAccess: false
    },
    PRO: {
      summaries: 1000,
      batchProcessing: true,
      customInstructions: true,
      exportFormats: true,
      apiAccess: true
    },
    ENTERPRISE: {
      summaries: Infinity,
      batchProcessing: true,
      customInstructions: true,
      exportFormats: true,
      apiAccess: true
    }
  },

  // Export Formats
  EXPORT_FORMATS: {
    TXT: 'txt',
    PDF: 'pdf',
    MD: 'md',
    JSON: 'json',
    HTML: 'html'
  },

  // AI Models
  AI_MODELS: {
    GPT4: 'gpt-4',
    GPT35: 'gpt-3.5-turbo',
    CLAUDE: 'claude-2'
  },

  // Response Messages
  MESSAGES: {
    INVALID_CREDENTIALS: 'Invalid credentials',
    USER_NOT_FOUND: 'User not found',
    SUMMARY_NOT_FOUND: 'Summary not found',
    INVALID_YOUTUBE_URL: 'Invalid YouTube URL',
    RATE_LIMIT_EXCEEDED: 'Rate limit exceeded',
    INSUFFICIENT_PERMISSIONS: 'Insufficient permissions',
    SUBSCRIPTION_LIMIT_REACHED: 'Subscription limit reached'
  },

  // Error Codes
  ERROR_CODES: {
    VALIDATION_ERROR: 'VALIDATION_ERROR',
    AUTH_ERROR: 'AUTH_ERROR',
    NOT_FOUND: 'NOT_FOUND',
    RATE_LIMIT: 'RATE_LIMIT',
    SUBSCRIPTION_LIMIT: 'SUBSCRIPTION_LIMIT',
    EXTERNAL_API_ERROR: 'EXTERNAL_API_ERROR',
    INTERNAL_ERROR: 'INTERNAL_ERROR'
  },

  // Default Settings
  DEFAULTS: {
    SUMMARY_LENGTH: 'medium',
    SUMMARY_FORMAT: 'paragraph',
    TONE: 'professional',
    LANGUAGE: 'english',
    PAGE_LIMIT: 10,
    CACHE_TTL: 3600 // 1 hour in seconds
  },

  // Rate Limiting
  RATE_LIMITS: {
    FREE: {
      windowMs: 15 * 60 * 1000, // 15 minutes
      max: 100 // 100 requests per windowMs
    },
    PRO: {
      windowMs: 15 * 60 * 1000,
      max: 1000
    },
    ENTERPRISE: {
      windowMs: 15 * 60 * 1000,
      max: 10000
    }
  }
};