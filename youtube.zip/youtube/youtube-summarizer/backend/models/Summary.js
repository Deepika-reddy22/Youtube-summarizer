import mongoose from 'mongoose';

const summarySchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.ObjectId,
    ref: 'User',
    required: true
  },
  videoInfo: {
    videoId: {
      type: String,
      required: true
    },
    title: {
      type: String,
      required: true
    },
    channel: {
      type: String,
      required: true
    },
    duration: String,
    thumbnail: String,
    views: String,
    likes: String,
    publishedAt: Date
  },
  summary: {
    type: String,
    required: true
  },
  options: {
    language: {
      type: String,
      default: 'english'
    },
    length: {
      type: String,
      enum: ['short', 'medium', 'long'],
      default: 'medium'
    },
    format: {
      type: String,
      enum: ['paragraph', 'bullet', 'structured'],
      default: 'paragraph'
    },
    tone: {
      type: String,
      enum: ['professional', 'casual', 'academic', 'simple', 'detailed'],
      default: 'professional'
    },
    includeTimestamps: {
      type: Boolean,
      default: false
    },
    focusAreas: [String],
    customInstructions: String
  },
  analytics: {
    wordCount: Number,
    readingTime: Number,
    readabilityScore: Number,
    keyPoints: [String],
    sentiment: {
      type: String,
      enum: ['positive', 'neutral', 'negative']
    }
  },
  isFavorite: {
    type: Boolean,
    default: false
  },
  isPublic: {
    type: Boolean,
    default: false
  },
  shareToken: String,
  tags: [String],
  aiModel: {
    type: String,
    default: 'gpt-4'
  },
  processingTime: Number
}, {
  timestamps: true
});

summarySchema.index({ user: 1, createdAt: -1 });
summarySchema.index({ 'videoInfo.videoId': 1 });
summarySchema.index({ isPublic: 1, createdAt: -1 });

export default mongoose.model('Summary', summarySchema);