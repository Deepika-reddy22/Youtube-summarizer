import React, { createContext, useContext, useState, useEffect } from 'react';

const languages = {
  en: { code: 'en', name: 'English', flag: '🇺🇸' },
  es: { code: 'es', name: 'Spanish', flag: '🇪🇸' },
  fr: { code: 'fr', name: 'French', flag: '🇫🇷' },
  de: { code: 'de', name: 'German', flag: '🇩🇪' },
  it: { code: 'it', name: 'Italian', flag: '🇮🇹' },
  pt: { code: 'pt', name: 'Portuguese', flag: '🇵🇹' },
  ru: { code: 'ru', name: 'Russian', flag: '🇷🇺' },
  ja: { code: 'ja', name: 'Japanese', flag: '🇯🇵' },
  ko: { code: 'ko', name: 'Korean', flag: '🇰🇷' },
  zh: { code: 'zh', name: 'Chinese', flag: '🇨🇳' },
  hi: { code: 'hi', name: 'Hindi', flag: '🇮🇳' },
  ar: { code: 'ar', name: 'Arabic', flag: '🇸🇦' }
};

const LanguageContext = createContext();

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};

export const LanguageProvider = ({ children }) => {
  const [currentLanguage, setCurrentLanguage] = useState(() => {
    const savedLang = localStorage.getItem('language');
    return savedLang || 'en';
  });

  useEffect(() => {
    localStorage.setItem('language', currentLanguage);
  }, [currentLanguage]);

  const changeLanguage = (langCode) => {
    setCurrentLanguage(langCode);
  };

  const value = {
    currentLanguage,
    languages,
    changeLanguage,
  };

  return (
    <LanguageContext.Provider value={value}>
      {children}
    </LanguageContext.Provider>
  );
};