import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { ThemeProvider } from './contexts/ThemeContext';
import { LanguageProvider } from './contexts/LanguageContext';
import Login from './components/Auth/Login';
import Signup from './components/Auth/Signup';
import Dashboard from './components/Dashboard/Dashboard';
import Navbar from './components/Common/Navbar';
import Footer from './components/Common/Footer';
import './styles/Common.css';
import './styles/Theme.css';

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  // Check if user is already logged in (from localStorage)
  useEffect(() => {
    const checkAuthStatus = () => {
      try {
        const savedUser = localStorage.getItem('currentUser');
        if (savedUser) {
          const userData = JSON.parse(savedUser);
          setUser(userData);
          setIsAuthenticated(true);
        }
      } catch (error) {
        console.error('Error checking auth status:', error);
        // Clear corrupted data
        localStorage.removeItem('currentUser');
      } finally {
        setIsLoading(false);
      }
    };

    checkAuthStatus();
  }, []);

  const handleLogin = (userData) => {
    // Save user to localStorage for persistent login
    localStorage.setItem('currentUser', JSON.stringify(userData));
    setUser(userData);
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    // Remove user from localStorage
    localStorage.removeItem('currentUser');
    setUser(null);
    setIsAuthenticated(false);
  };

  // Show loading spinner while checking authentication
  if (isLoading) {
    return (
      <div className="loading-screen">
        <div className="spinner"></div>
        <p>Loading...</p>
      </div>
    );
  }

  return (
    <ThemeProvider>
      <LanguageProvider>
        <Router>
          <div className="App">
            <Navbar isAuthenticated={isAuthenticated} user={user} onLogout={handleLogout} />
            <main>
              <Routes>
                <Route 
                  path="/login" 
                  element={
                    !isAuthenticated ? 
                    <Login onLogin={handleLogin} /> : 
                    <Navigate to="/dashboard" replace />
                  } 
                />
                <Route 
                  path="/signup" 
                  element={
                    !isAuthenticated ? 
                    <Signup /> : 
                    <Navigate to="/dashboard" replace />
                  } 
                />
                <Route 
                  path="/dashboard" 
                  element={
                    isAuthenticated ? 
                    <Dashboard user={user} /> : 
                    <Navigate to="/login" replace />
                  } 
                />
                <Route 
                  path="/" 
                  element={
                    <Navigate to={isAuthenticated ? "/dashboard" : "/login"} replace />
                  } 
                />
                {/* Fallback route for undefined paths */}
                <Route 
                  path="*" 
                  element={
                    <Navigate to={isAuthenticated ? "/dashboard" : "/login"} replace />
                  } 
                />
              </Routes>
            </main>
            <Footer />
          </div>
        </Router>
      </LanguageProvider>
    </ThemeProvider>
  );
}

export default App;