import React, { useState, useEffect } from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { useTheme } from '../../contexts/ThemeContext';
import '../../styles/VideoSummarizer.css';

// API service for backend communication
const API_BASE_URL = 'http://localhost:5000/api';

const VideoSummarizer = () => {
  const [url, setUrl] = useState('');
  const [summary, setSummary] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [videoInfo, setVideoInfo] = useState(null);
  const [summaryLength, setSummaryLength] = useState('medium');
  const [includeTimestamps, setIncludeTimestamps] = useState(false);
  const [favoriteUrls, setFavoriteUrls] = useState([]);
  const [recentUrls, setRecentUrls] = useState([]);
  const [summaryFormat, setSummaryFormat] = useState('paragraph');
  const [exportFormat, setExportFormat] = useState('txt');
  const [urlSuggestions, setUrlSuggestions] = useState([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [batchUrls, setBatchUrls] = useState('');
  const [batchMode, setBatchMode] = useState(false);
  const [batchProgress, setBatchProgress] = useState([]);
  const [customInstructions, setCustomInstructions] = useState('');
  const [focusAreas, setFocusAreas] = useState([]);
  const [tone, setTone] = useState('professional');
  const [isShared, setIsShared] = useState(false);
  const [shareLink, setShareLink] = useState('');
  const [summaryStats, setSummaryStats] = useState(null);
  const [showShortcuts, setShowShortcuts] = useState(false);
  const [error, setError] = useState('');

  const { currentLanguage, languages } = useLanguage();
  const { isDarkMode } = useTheme();

  const summaryLengths = {
    short: 'Short (Key Points)',
    medium: 'Medium (Detailed)',
    long: 'Long (Comprehensive)'
  };

  const summaryFormats = {
    paragraph: 'Paragraph',
    bullet: 'Bullet Points',
    structured: 'Structured'
  };

  const exportOptions = {
    txt: 'Text File',
    pdf: 'PDF Document',
    md: 'Markdown',
    json: 'JSON Data',
    html: 'HTML Page'
  };

  const toneOptions = {
    professional: 'Professional',
    casual: 'Casual',
    academic: 'Academic',
    simple: 'Simple Language',
    detailed: 'Highly Detailed'
  };

  const focusOptions = [
    'Key Concepts',
    'Step-by-Step Instructions',
    'Main Arguments',
    'Technical Details',
    'Practical Applications',
    'Critical Analysis',
    'Beginner Friendly',
    'Advanced Insights'
  ];

  // Load favorite and recent URLs from localStorage
  useEffect(() => {
    const savedFavorites = JSON.parse(localStorage.getItem('favoriteUrls') || '[]');
    const savedRecent = JSON.parse(localStorage.getItem('recentUrls') || '[]');
    setFavoriteUrls(savedFavorites);
    setRecentUrls(savedRecent);
  }, []);

  // API Service Functions
  const apiService = {
    // Validate YouTube URL
    validateUrl: async (videoUrl) => {
      try {
        const response = await fetch(`${API_BASE_URL}/validate-url`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ videoUrl })
        });
        
        if (!response.ok) {
          throw new Error('Failed to validate URL');
        }
        
        return await response.json();
      } catch (error) {
        console.error('URL validation error:', error);
        throw new Error('Failed to validate YouTube URL');
      }
    },

    // Create summary
    createSummary: async (videoUrl, options) => {
      try {
        const response = await fetch(`${API_BASE_URL}/summaries`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            videoUrl,
            options
          })
        });
        
        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.message || 'Failed to create summary');
        }
        
        return await response.json();
      } catch (error) {
        console.error('Summary creation error:', error);
        throw error;
      }
    },

    // Demo login (for testing without real auth)
    demoLogin: async (email, password) => {
      try {
        const response = await fetch(`${API_BASE_URL}/auth/login`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ email, password })
        });
        
        if (!response.ok) {
          throw new Error('Login failed');
        }
        
        return await response.json();
      } catch (error) {
        console.error('Login error:', error);
        // Fallback to mock login for demo
        return {
          success: true,
          token: 'demo-token',
          user: {
            id: 1,
            name: 'Demo User',
            email: email,
            preferences: {
              language: 'english',
              summaryLength: 'medium',
              darkMode: false
            }
          }
        };
      }
    }
  };

  const handleUrlChange = (value) => {
    setUrl(value);
    setError('');
    
    if (value.length > 10) {
      const suggestions = [...favoriteUrls, ...recentUrls]
        .filter(u => u.toLowerCase().includes(value.toLowerCase()))
        .slice(0, 5);
      setUrlSuggestions(suggestions);
      setShowSuggestions(suggestions.length > 0);
    } else {
      setShowSuggestions(false);
    }
  };

  const selectSuggestion = (suggestion) => {
    setUrl(suggestion);
    setShowSuggestions(false);
  };

  const handleSummarize = async (e) => {
    if (e && e.preventDefault) e.preventDefault();
    if (!url) {
      setError('Please enter a YouTube URL');
      return;
    }

    setIsLoading(true);
    setError('');
    setSummary('');
    setVideoInfo(null);
    setSummaryStats(null);

    try {
      // First validate the URL
      const validationResult = await apiService.validateUrl(url);
      
      if (!validationResult.success || !validationResult.data.isValid) {
        throw new Error('Please enter a valid YouTube URL');
      }

      console.log('URL validated, creating summary...');

      // Prepare options for the backend
      const options = {
        language: currentLanguage,
        length: summaryLength,
        format: summaryFormat,
        tone: tone,
        includeTimestamps: includeTimestamps,
        focusAreas: focusAreas,
        customInstructions: customInstructions
      };

      // Create the summary using the backend API
      const result = await apiService.createSummary(url, options);
      
      if (result.success) {
        const summaryData = result.data;
        
        // Update state with real data from backend
        setVideoInfo(summaryData.videoInfo);
        setSummary(summaryData.summary);
        setSummaryStats(summaryData.analytics);
        
        // Save to recent URLs
        const updatedRecent = [url, ...recentUrls.filter(u => u !== url)].slice(0, 5);
        setRecentUrls(updatedRecent);
        localStorage.setItem('recentUrls', JSON.stringify(updatedRecent));

        console.log('Summary created successfully:', summaryData.videoInfo.title);
      } else {
        throw new Error(result.message || 'Failed to generate summary');
      }

    } catch (error) {
      console.error('Summarization error:', error);
      setError(error.message || 'Failed to generate summary. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const clearForm = () => {
    setUrl('');
    setSummary('');
    setVideoInfo(null);
    setSummaryStats(null);
    setCustomInstructions('');
    setFocusAreas([]);
    setShowSuggestions(false);
    setIsShared(false);
    setError('');
  };

  const toggleFavorite = () => {
    const updatedFavorites = favoriteUrls.includes(url) 
      ? favoriteUrls.filter(u => u !== url)
      : [...favoriteUrls, url];
    
    setFavoriteUrls(updatedFavorites);
    localStorage.setItem('favoriteUrls', JSON.stringify(updatedFavorites));
  };

  const copySummary = () => {
    navigator.clipboard.writeText(summary);
    alert('Summary copied to clipboard!');
  };

  const downloadSummary = (format = exportFormat) => {
    const filename = `summary-${Date.now()}`;
    
    switch (format) {
      case 'md':
        exportAsMarkdown(summary, videoInfo, filename);
        break;
      case 'json':
        exportAsJSON(summary, videoInfo, filename);
        break;
      case 'html':
        exportAsHTML(summary, videoInfo, filename);
        break;
      default:
        exportAsText(summary, videoInfo, filename);
    }
  };

  const exportAsText = (content, info, filename) => {
    const textContent = `${info?.title || 'Video Summary'}
${'='.repeat(info?.title?.length || 12)}

${content}

---
Channel: ${info?.channel || 'Unknown'}
Duration: ${info?.duration || 'Unknown'}
Language: ${languages[currentLanguage]?.name || 'English'}
Summary Length: ${summaryLengths[summaryLength]}
Format: ${summaryFormats[summaryFormat]}
Generated: ${new Date().toLocaleString()}
Exported by SummarizeTube`;

    downloadFile(textContent, `${filename}.txt`, 'text/plain');
  };

  const exportAsMarkdown = (content, info, filename) => {
    const markdownContent = `# ${info?.title || 'Video Summary'}

**Channel:** ${info?.channel || 'Unknown'}  
**Duration:** ${info?.duration || 'Unknown'}  
**Language:** ${languages[currentLanguage]?.name || 'English'}  
**Summary Length:** ${summaryLengths[summaryLength]}  
**Format:** ${summaryFormats[summaryFormat]}  
**Generated:** ${new Date().toLocaleString()}

## Summary
${content}

${focusAreas.length > 0 ? `\n## Focus Areas\n${focusAreas.map(area => `- ${area}`).join('\n')}` : ''}

${customInstructions ? `\n## Custom Instructions\n${customInstructions}` : ''}

---
*Generated by [SummarizeTube](https://summarizetube.com)*`;

    downloadFile(markdownContent, `${filename}.md`, 'text/markdown');
  };

  const exportAsJSON = (content, info, filename) => {
    const jsonData = {
      metadata: {
        title: info?.title,
        channel: info?.channel,
        duration: info?.duration,
        thumbnail: info?.thumbnail,
        generatedAt: new Date().toISOString(),
        language: languages[currentLanguage]?.name || 'English',
        summaryLength: summaryLengths[summaryLength],
        format: summaryFormats[summaryFormat],
        tone: toneOptions[tone],
        focusAreas: focusAreas,
        customInstructions: customInstructions
      },
      summary: content,
      analytics: summaryStats
    };
    
    downloadFile(JSON.stringify(jsonData, null, 2), `${filename}.json`, 'application/json');
  };

  const exportAsHTML = (content, info, filename) => {
    const htmlContent = `<!DOCTYPE html>
<html>
<head>
    <title>${info?.title || 'Video Summary'}</title>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; margin: 40px; }
        .header { border-bottom: 2px solid #667eea; padding-bottom: 20px; }
        .metadata { background: #f8f9fa; padding: 15px; border-radius: 5px; margin: 20px 0; }
        .summary { white-space: pre-line; margin: 20px 0; }
        .footer { margin-top: 40px; padding-top: 20px; border-top: 1px solid #ddd; color: #666; }
    </style>
</head>
<body>
    <div class="header">
        <h1>${info?.title || 'Video Summary'}</h1>
    </div>
    
    <div class="metadata">
        <p><strong>Channel:</strong> ${info?.channel || 'Unknown'}</p>
        <p><strong>Duration:</strong> ${info?.duration || 'Unknown'}</p>
        <p><strong>Language:</strong> ${languages[currentLanguage]?.name || 'English'}</p>
        <p><strong>Generated:</strong> ${new Date().toLocaleString()}</p>
    </div>
    
    <div class="summary">${content}</div>
    
    <div class="footer">
        <p>Generated by SummarizeTube</p>
    </div>
</body>
</html>`;

    downloadFile(htmlContent, `${filename}.html`, 'text/html');
  };

  const downloadFile = (content, filename, mimeType) => {
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !isLoading) {
      handleSummarize(e);
    }
  };

  // Rest of your component remains the same...
  const KeyboardShortcutsModal = () => (
    <div className="shortcuts-modal-overlay" onClick={() => setShowShortcuts(false)}>
      <div className="shortcuts-modal" onClick={(e) => e.stopPropagation()}>
        <div className="shortcuts-header">
          <h3>Keyboard Shortcuts</h3>
          <button onClick={() => setShowShortcuts(false)} className="close-btn">
            <i className="fas fa-times"></i>
          </button>
        </div>
        <div className="shortcuts-content">
          <div className="shortcut-list">
            <div className="shortcut-item">
              <kbd>Ctrl</kbd> + <kbd>K</kbd>
              <span>Focus URL input</span>
            </div>
            <div className="shortcut-item">
              <kbd>Ctrl</kbd> + <kbd>Enter</kbd>
              <span>Start summarization</span>
            </div>
            <div className="shortcut-item">
              <kbd>Escape</kbd>
              <span>Clear form</span>
            </div>
            <div className="shortcut-item">
              <kbd>Ctrl</kbd> + <kbd>C</kbd>
              <span>Copy summary</span>
            </div>
            <div className="shortcut-item">
              <kbd>Ctrl</kbd> + <kbd>?</kbd>
              <span>Show shortcuts</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="summarizer">
      <div className="summarizer-header">
        <h2>YouTube Video Summarizer</h2>
        <p>Paste any YouTube URL to get an AI-generated summary</p>
        <button 
          className="shortcuts-help-btn"
          onClick={() => setShowShortcuts(true)}
          title="Keyboard Shortcuts"
        >
          <i className="fas fa-keyboard"></i>
          Shortcuts
        </button>
      </div>

      {/* Error Display */}
      {error && (
        <div className="error-message">
          <i className="fas fa-exclamation-triangle"></i>
          {error}
        </div>
      )}

      {/* Your existing JSX structure remains the same, but now it will use real data */}
      <form onSubmit={handleSummarize} className="url-form">
        <div className="input-group">
          <div className="url-input-container">
            <input
              type="url"
              value={url}
              onChange={(e) => handleUrlChange(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Paste any YouTube URL here... (Ctrl+K to focus)"
              className="url-input"
              disabled={isLoading}
            />
            {url && (
              <button
                type="button"
                className={`favorite-btn ${favoriteUrls.includes(url) ? 'active' : ''}`}
                onClick={toggleFavorite}
                title={favoriteUrls.includes(url) ? 'Remove from favorites' : 'Add to favorites'}
              >
                <i className="fas fa-star"></i>
              </button>
            )}
          </div>
          <button type="submit" className="summarize-btn" disabled={isLoading || !url}>
            {isLoading ? (
              <>
                <i className="fas fa-spinner fa-spin"></i>
                Analyzing Video...
              </>
            ) : (
              <>
                <i className="fas fa-magic"></i>
                Summarize
              </>
            )}
          </button>
        </div>

        {showSuggestions && (
          <div className="url-suggestions">
            {urlSuggestions.map((suggestion, index) => (
              <div
                key={index}
                className="suggestion-item"
                onClick={() => selectSuggestion(suggestion)}
              >
                <i className="fas fa-history"></i>
                {suggestion}
              </div>
            ))}
          </div>
        )}

        {/* Options sections remain the same */}
        <div className="summary-options">
          <div className="option-group">
            <label htmlFor="summary-length">Summary Length:</label>
            <select 
              id="summary-length"
              value={summaryLength}
              onChange={(e) => setSummaryLength(e.target.value)}
              className="option-select"
              disabled={isLoading}
            >
              {Object.entries(summaryLengths).map(([value, label]) => (
                <option key={value} value={value}>{label}</option>
              ))}
            </select>
          </div>

          <div className="option-group">
            <label htmlFor="summary-format">Format:</label>
            <select 
              id="summary-format"
              value={summaryFormat}
              onChange={(e) => setSummaryFormat(e.target.value)}
              className="option-select"
              disabled={isLoading}
            >
              {Object.entries(summaryFormats).map(([value, label]) => (
                <option key={value} value={value}>{label}</option>
              ))}
            </select>
          </div>

          <div className="option-group">
            <label htmlFor="tone">Tone:</label>
            <select 
              id="tone"
              value={tone}
              onChange={(e) => setTone(e.target.value)}
              className="option-select"
              disabled={isLoading}
            >
              {Object.entries(toneOptions).map(([value, label]) => (
                <option key={value} value={value}>{label}</option>
              ))}
            </select>
          </div>
          
          <div className="option-group">
            <label className="checkbox-label">
              <input
                type="checkbox"
                checked={includeTimestamps}
                onChange={(e) => setIncludeTimestamps(e.target.checked)}
                disabled={isLoading}
              />
              Include Timestamps
            </label>
          </div>
        </div>

        {/* Advanced Options remain the same */}
        <div className="advanced-options">
          <h4>Advanced Options</h4>
          
          <div className="option-group full-width">
            <label>Focus Areas:</label>
            <div className="focus-chips">
              {focusOptions.map(area => (
                <button
                  key={area}
                  type="button"
                  className={`focus-chip ${focusAreas.includes(area) ? 'active' : ''}`}
                  onClick={() => {
                    setFocusAreas(prev => 
                      prev.includes(area) 
                        ? prev.filter(a => a !== area)
                        : [...prev, area]
                    );
                  }}
                >
                  {area}
                </button>
              ))}
            </div>
          </div>

          <div className="option-group full-width">
            <label htmlFor="custom-instructions">Custom Instructions:</label>
            <textarea
              id="custom-instructions"
              value={customInstructions}
              onChange={(e) => setCustomInstructions(e.target.value)}
              placeholder="Add specific instructions for the summary (e.g., 'Focus on the technical implementation', 'Explain like I'm 10')"
              className="custom-instructions"
              rows="3"
              disabled={isLoading}
            />
          </div>
        </div>
      </form>

      {/* Results section - Now shows real data from backend */}
      {videoInfo && (
        <div className="video-preview">
          <div className="video-thumbnail">
            <img src={videoInfo.thumbnail} alt={videoInfo.title} />
          </div>
          <div className="video-details">
            <h3>{videoInfo.title}</h3>
            <p className="channel">{videoInfo.channel}</p>
            <div className="video-stats">
              <span className="duration">{videoInfo.duration}</span>
              <span className="views">{videoInfo.views} views</span>
              {videoInfo.likes && <span className="likes">{videoInfo.likes} likes</span>}
            </div>
          </div>
        </div>
      )}

      {summary && (
        <div className="summary-section">
          <div className="summary-header">
            <div>
              <h3>Video Summary</h3>
              <div className="summary-meta">
                <span className="summary-language">
                  Language: {languages[currentLanguage]?.name || 'English'}
                </span>
                <span className="summary-length">
                  Length: {summaryLengths[summaryLength]}
                </span>
                <span className="summary-format">
                  Format: {summaryFormats[summaryFormat]}
                </span>
              </div>
              {summaryStats && (
                <div className="summary-analytics">
                  <span>{summaryStats.wordCount} words</span>
                  <span>{summaryStats.readingTime} min read</span>
                  <span>{summaryStats.readabilityScore}% readable</span>
                </div>
              )}
            </div>
            <div className="summary-header-actions">
              <button onClick={copySummary} className="action-btn" title="Copy summary">
                <i className="fas fa-copy"></i>
              </button>
              <button onClick={() => downloadSummary()} className="action-btn" title="Download summary">
                <i className="fas fa-download"></i>
              </button>
              <button onClick={clearForm} className="clear-btn">
                <i className="fas fa-times"></i>
                Clear
              </button>
            </div>
          </div>
          <div className="summary-content">
            <pre>{summary}</pre>
          </div>
          <div className="summary-actions">
            <button onClick={copySummary} className="action-btn">
              <i className="fas fa-copy"></i>
              Copy Summary
            </button>
            <div className="export-dropdown">
              <button className="action-btn export-main-btn">
                <i className="fas fa-download"></i>
                Export As
              </button>
              <div className="export-dropdown-content">
                {Object.entries(exportOptions).map(([value, label]) => (
                  <button
                    key={value}
                    onClick={() => downloadSummary(value)}
                    className="export-option"
                  >
                    {label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {isLoading && (
        <div className="loading">
          <div className="spinner"></div>
          <p>Analyzing video content...</p>
          <div className="loading-details">
            <span>Processing: {url}</span>
            <span>Language: {languages[currentLanguage]?.name || 'English'}</span>
            <span>Length: {summaryLengths[summaryLength]}</span>
          </div>
        </div>
      )}

      {showShortcuts && <KeyboardShortcutsModal />}
    </div>
  );
};

export default VideoSummarizer;