import React, { useState, useEffect } from 'react';
import '../../styles/Favorites.css';

const Favorites = () => {
  const [favorites, setFavorites] = useState([]);
  const [filter, setFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    // Load favorites from localStorage or mock data
    const mockFavorites = [
      {
        id: 1,
        videoInfo: {
          title: 'React Hooks Explained - Complete Guide',
          channel: 'Web Dev Simplified',
          duration: '15:30',
          thumbnail: '/api/placeholder/200/112'
        },
        summary: 'This video covers all React hooks including useState, useEffect, useContext, and custom hooks. Learn how to manage state and side effects in functional components.',
        createdAt: '2024-01-15',
        tags: ['React', 'JavaScript', 'Web Development'],
        language: 'english',
        length: 'medium'
      },
      {
        id: 2,
        videoInfo: {
          title: 'Python Data Analysis with Pandas',
          channel: 'Data Science Dojo',
          duration: '22:45',
          thumbnail: '/api/placeholder/200/112'
        },
        summary: 'Comprehensive guide to data analysis using Python Pandas library. Covers data manipulation, cleaning, and visualization techniques for data science projects.',
        createdAt: '2024-01-12',
        tags: ['Python', 'Data Science', 'Pandas'],
        language: 'english',
        length: 'detailed'
      },
      {
        id: 3,
        videoInfo: {
          title: 'CSS Grid vs Flexbox - When to Use Which',
          channel: 'CSS Tricks',
          duration: '18:20',
          thumbnail: '/api/placeholder/200/112'
        },
        summary: 'Detailed comparison between CSS Grid and Flexbox layout systems. Learn when to use each layout method for optimal web design results.',
        createdAt: '2024-01-10',
        tags: ['CSS', 'Web Design', 'Layout'],
        language: 'english',
        length: 'short'
      }
    ];

    setFavorites(mockFavorites);
  }, []);

  const removeFromFavorites = (id) => {
    if (window.confirm('Are you sure you want to remove this summary from favorites?')) {
      setFavorites(prev => prev.filter(fav => fav.id !== id));
    }
  };

  const clearAllFavorites = () => {
    if (window.confirm('Are you sure you want to remove all favorites? This action cannot be undone.')) {
      setFavorites([]);
    }
  };

  const exportFavorites = () => {
    const exportData = {
      exportedAt: new Date().toISOString(),
      totalFavorites: favorites.length,
      favorites: favorites
    };
    
    const dataStr = JSON.stringify(exportData, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `favorites-backup-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const filteredFavorites = favorites.filter(fav => {
    const matchesSearch = fav.videoInfo.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         fav.videoInfo.channel.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         fav.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
    
    if (filter === 'all') return matchesSearch;
    if (filter === 'short') return matchesSearch && fav.length === 'short';
    if (filter === 'medium') return matchesSearch && fav.length === 'medium';
    if (filter === 'detailed') return matchesSearch && fav.length === 'detailed';
    
    return matchesSearch;
  });

  return (
    <div className="favorites-container">
      <div className="favorites-header">
        <div className="header-content">
          <h2>Favorite Summaries</h2>
          <p>Your saved and starred summaries for quick access</p>
        </div>
        
        <div className="header-actions">
          <button className="action-btn export-btn" onClick={exportFavorites}>
            <i className="fas fa-download"></i>
            Export Favorites
          </button>
          {favorites.length > 0 && (
            <button className="action-btn clear-btn" onClick={clearAllFavorites}>
              <i className="fas fa-trash"></i>
              Clear All
            </button>
          )}
        </div>
      </div>

      {/* Filters and Search */}
      <div className="filters-section">
        <div className="search-box">
          <i className="fas fa-search"></i>
          <input 
            type="text" 
            placeholder="Search favorites..." 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        
        <div className="filter-buttons">
          <button 
            className={`filter-btn ${filter === 'all' ? 'active' : ''}`}
            onClick={() => setFilter('all')}
          >
            All
          </button>
          <button 
            className={`filter-btn ${filter === 'short' ? 'active' : ''}`}
            onClick={() => setFilter('short')}
          >
            Short
          </button>
          <button 
            className={`filter-btn ${filter === 'medium' ? 'active' : ''}`}
            onClick={() => setFilter('medium')}
          >
            Medium
          </button>
          <button 
            className={`filter-btn ${filter === 'detailed' ? 'active' : ''}`}
            onClick={() => setFilter('detailed')}
          >
            Detailed
          </button>
        </div>
      </div>

      {/* Favorites Grid */}
      {filteredFavorites.length > 0 ? (
        <div className="favorites-grid">
          {filteredFavorites.map((fav) => (
            <div key={fav.id} className="favorite-card">
              <div className="card-header">
                <div className="video-thumbnail">
                  <img src={fav.videoInfo.thumbnail} alt={fav.videoInfo.title} />
                  <div className="duration-badge">
                    {fav.videoInfo.duration}
                  </div>
                </div>
                
                <div className="video-info">
                  <h3 className="video-title">{fav.videoInfo.title}</h3>
                  <p className="video-channel">{fav.videoInfo.channel}</p>
                  
                  <div className="summary-meta">
                    <span className={`length-badge ${fav.length}`}>
                      <i className="fas fa-ruler"></i>
                      {fav.length.charAt(0).toUpperCase() + fav.length.slice(1)}
                    </span>
                    <span className="language-badge">
                      <i className="fas fa-language"></i>
                      {fav.language}
                    </span>
                    <span className="date-badge">
                      <i className="fas fa-calendar"></i>
                      {new Date(fav.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                </div>
              </div>

              <div className="card-content">
                <p className="summary-preview">{fav.summary}</p>
                
                <div className="tags-container">
                  {fav.tags.map((tag, index) => (
                    <span key={index} className="tag">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>

              <div className="card-actions">
                <button className="action-btn view-btn">
                  <i className="fas fa-eye"></i>
                  View
                </button>
                <button className="action-btn share-btn">
                  <i className="fas fa-share"></i>
                  Share
                </button>
                <button 
                  className="action-btn remove-btn"
                  onClick={() => removeFromFavorites(fav.id)}
                >
                  <i className="fas fa-trash"></i>
                  Remove
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="empty-state">
          <div className="empty-icon">
            <i className="far fa-star"></i>
          </div>
          <h3>No favorites yet</h3>
          <p>
            {searchTerm || filter !== 'all' 
              ? 'No favorites match your current filters. Try adjusting your search or filters.'
              : 'Star your favorite summaries to see them here for quick access.'
            }
          </p>
          {(searchTerm || filter !== 'all') && (
            <button 
              className="clear-filters-btn"
              onClick={() => {
                setSearchTerm('');
                setFilter('all');
              }}
            >
              Clear Filters
            </button>
          )}
        </div>
      )}

      {/* Favorites Stats */}
      {favorites.length > 0 && (
        <div className="favorites-stats">
          <div className="stat-item">
            <span className="stat-number">{favorites.length}</span>
            <span className="stat-label">Total Favorites</span>
          </div>
          <div className="stat-item">
            <span className="stat-number">
              {favorites.filter(fav => fav.length === 'detailed').length}
            </span>
            <span className="stat-label">Detailed Summaries</span>
          </div>
          <div className="stat-item">
            <span className="stat-number">
              {new Set(favorites.flatMap(fav => fav.tags)).size}
            </span>
            <span className="stat-label">Unique Tags</span>
          </div>
        </div>
      )}
    </div>
  );
};

export default Favorites;