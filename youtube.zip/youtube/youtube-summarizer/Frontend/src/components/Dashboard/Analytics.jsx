import React, { useState, useEffect } from 'react';
import '../../styles/Analytics.css';

const Analytics = () => {
  const [timeRange, setTimeRange] = useState('week');
  const [analytics, setAnalytics] = useState({
    summariesCreated: 0,
    timeSaved: 0,
    wordsProcessed: 0,
    favoriteTopics: []
  });

  const [chartData, setChartData] = useState([]);

  useEffect(() => {
    // Mock analytics data - replace with actual data from your backend
    const mockAnalytics = {
      summariesCreated: 47,
      timeSaved: 28,
      wordsProcessed: 23500,
      favoriteTopics: ['Technology', 'Education', 'Science', 'Tutorials']
    };

    const mockChartData = [
      { day: 'Mon', summaries: 5 },
      { day: 'Tue', summaries: 8 },
      { day: 'Wed', summaries: 6 },
      { day: 'Thu', summaries: 12 },
      { day: 'Fri', summaries: 7 },
      { day: 'Sat', summaries: 5 },
      { day: 'Sun', summaries: 4 }
    ];

    setAnalytics(mockAnalytics);
    setChartData(mockChartData);
  }, [timeRange]);

  const stats = [
    {
      title: 'Summaries Created',
      value: analytics.summariesCreated,
      change: '+12%',
      trend: 'up',
      icon: 'fas fa-file-alt'
    },
    {
      title: 'Time Saved (hours)',
      value: analytics.timeSaved,
      change: '+8%',
      trend: 'up',
      icon: 'fas fa-clock'
    },
    {
      title: 'Words Processed',
      value: (analytics.wordsProcessed / 1000).toFixed(1) + 'k',
      change: '+15%',
      trend: 'up',
      icon: 'fas fa-font'
    },
    {
      title: 'Productivity Score',
      value: '85%',
      change: '+5%',
      trend: 'up',
      icon: 'fas fa-chart-line'
    }
  ];

  return (
    <div className="analytics-container">
      <div className="analytics-header">
        <h2>Analytics Dashboard</h2>
        <p>Track your summarization productivity and insights</p>
        
        <div className="time-range-selector">
          <button 
            className={`time-btn ${timeRange === 'week' ? 'active' : ''}`}
            onClick={() => setTimeRange('week')}
          >
            Week
          </button>
          <button 
            className={`time-btn ${timeRange === 'month' ? 'active' : ''}`}
            onClick={() => setTimeRange('month')}
          >
            Month
          </button>
          <button 
            className={`time-btn ${timeRange === 'year' ? 'active' : ''}`}
            onClick={() => setTimeRange('year')}
          >
            Year
          </button>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="stats-overview">
        {stats.map((stat, index) => (
          <div key={index} className="analytics-stat-card">
            <div className="stat-icon">
              <i className={stat.icon}></i>
            </div>
            <div className="stat-content">
              <h3>{stat.value}</h3>
              <p>{stat.title}</p>
              <div className={`stat-change ${stat.trend}`}>
                <i className={`fas fa-arrow-${stat.trend}`}></i>
                {stat.change}
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="analytics-grid">
        {/* Summary Activity Chart */}
        <div className="analytics-card">
          <div className="card-header">
            <h3>Summary Activity</h3>
            <span>Last 7 days</span>
          </div>
          <div className="chart-container">
            <div className="bar-chart">
              {chartData.map((data, index) => (
                <div key={index} className="bar-wrapper">
                  <div 
                    className="bar" 
                    style={{ height: `${data.summaries * 10}%` }}
                    title={`${data.summaries} summaries`}
                  ></div>
                  <span>{data.day}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Popular Topics */}
        <div className="analytics-card">
          <div className="card-header">
            <h3>Popular Topics</h3>
            <span>Most summarized categories</span>
          </div>
          <div className="topics-list">
            {analytics.favoriteTopics.map((topic, index) => (
              <div key={index} className="topic-item">
                <div className="topic-info">
                  <span className="topic-name">{topic}</span>
                  <span className="topic-count">{Math.floor(Math.random() * 20) + 5} summaries</span>
                </div>
                <div className="topic-bar">
                  <div 
                    className="topic-progress" 
                    style={{ width: `${(index + 1) * 20}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Time Distribution */}
        <div className="analytics-card">
          <div className="card-header">
            <h3>Time Distribution</h3>
            <span>When you summarize most</span>
          </div>
          <div className="time-distribution">
            {[
              { period: 'Morning (6AM-12PM)', percentage: 35 },
              { period: 'Afternoon (12PM-6PM)', percentage: 45 },
              { period: 'Evening (6PM-12AM)', percentage: 15 },
              { period: 'Night (12AM-6AM)', percentage: 5 }
            ].map((item, index) => (
              <div key={index} className="time-item">
                <div className="time-period">{item.period}</div>
                <div className="time-bar">
                  <div 
                    className="time-progress" 
                    style={{ width: `${item.percentage}%` }}
                  ></div>
                </div>
                <div className="time-percentage">{item.percentage}%</div>
              </div>
            ))}
          </div>
        </div>

        {/* Efficiency Metrics */}
        <div className="analytics-card">
          <div className="card-header">
            <h3>Efficiency Metrics</h3>
            <span>Your summary performance</span>
          </div>
          <div className="metrics-grid">
            <div className="metric-item">
              <div className="metric-value">92%</div>
              <div className="metric-label">Accuracy Score</div>
            </div>
            <div className="metric-item">
              <div className="metric-value">2.3min</div>
              <div className="metric-label">Avg. Processing Time</div>
            </div>
            <div className="metric-item">
              <div className="metric-value">87%</div>
              <div className="metric-label">Content Retention</div>
            </div>
            <div className="metric-item">
              <div className="metric-value">4.8/5</div>
              <div className="metric-label">User Rating</div>
            </div>
          </div>
        </div>

        {/* Recent Activity */}
        <div className="analytics-card">
          <div className="card-header">
            <h3>Recent Activity</h3>
            <span>Latest summaries</span>
          </div>
          <div className="activity-list">
            {[
              { action: 'Created summary', title: 'React Hooks Tutorial', time: '2 hours ago' },
              { action: 'Exported summary', title: 'AI Basics Explained', time: '5 hours ago' },
              { action: 'Favorited summary', title: 'JavaScript Arrays', time: '1 day ago' },
              { action: 'Shared summary', title: 'CSS Grid Layout', time: '2 days ago' }
            ].map((activity, index) => (
              <div key={index} className="activity-item">
                <div className="activity-icon">
                  <i className="fas fa-circle"></i>
                </div>
                <div className="activity-content">
                  <div className="activity-action">{activity.action}</div>
                  <div className="activity-title">{activity.title}</div>
                  <div className="activity-time">{activity.time}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Goals & Achievements */}
        <div className="analytics-card">
          <div className="card-header">
            <h3>Goals & Achievements</h3>
            <span>Your progress</span>
          </div>
          <div className="goals-list">
            <div className="goal-item completed">
              <i className="fas fa-trophy"></i>
              <span>First Summary</span>
            </div>
            <div className="goal-item completed">
              <i className="fas fa-star"></i>
              <span>10 Summaries</span>
            </div>
            <div className="goal-item in-progress">
              <i className="fas fa-rocket"></i>
              <span>50 Summaries (45/50)</span>
            </div>
            <div className="goal-item locked">
              <i className="fas fa-crown"></i>
              <span>100 Summaries</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Analytics;