import React, { useState } from 'react';
import '../../styles/Settings.css';

const Settings = () => {
  const [settings, setSettings] = useState({
    language: 'english',
    summaryLength: 'medium',
    autoSave: true,
    notifications: true,
    darkMode: false,
    exportFormat: 'text',
    aiModel: 'gpt-4'
  });

  const handleSettingChange = (key, value) => {
    setSettings(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const resetToDefaults = () => {
    if (window.confirm('Are you sure you want to reset all settings to defaults?')) {
      setSettings({
        language: 'english',
        summaryLength: 'medium',
        autoSave: true,
        notifications: true,
        darkMode: false,
        exportFormat: 'text',
        aiModel: 'gpt-4'
      });
    }
  };

  return (
    <div className="settings-container">
      <div className="settings-header">
        <h2>Settings</h2>
        <p>Customize your SummarizeTube experience</p>
      </div>

      <div className="settings-grid">
        {/* General Settings */}
        <div className="settings-section">
          <h3>General</h3>
          <div className="setting-item">
            <label>Default Language</label>
            <select 
              value={settings.language}
              onChange={(e) => handleSettingChange('language', e.target.value)}
            >
              <option value="english">English</option>
              <option value="spanish">Spanish</option>
              <option value="french">French</option>
              <option value="german">German</option>
              <option value="chinese">Chinese</option>
            </select>
          </div>

          <div className="setting-item">
            <label>Default Summary Length</label>
            <select 
              value={settings.summaryLength}
              onChange={(e) => handleSettingChange('summaryLength', e.target.value)}
            >
              <option value="short">Short (Key Points)</option>
              <option value="medium">Medium (Detailed)</option>
              <option value="long">Long (Comprehensive)</option>
            </select>
          </div>

          <div className="setting-item">
            <label>Default Export Format</label>
            <select 
              value={settings.exportFormat}
              onChange={(e) => handleSettingChange('exportFormat', e.target.value)}
            >
              <option value="text">Text File</option>
              <option value="pdf">PDF</option>
              <option value="markdown">Markdown</option>
              <option value="json">JSON</option>
            </select>
          </div>
        </div>

        {/* AI Settings */}
        <div className="settings-section">
          <h3>AI Preferences</h3>
          <div className="setting-item">
            <label>AI Model</label>
            <select 
              value={settings.aiModel}
              onChange={(e) => handleSettingChange('aiModel', e.target.value)}
            >
              <option value="gpt-4">GPT-4 (Recommended)</option>
              <option value="gpt-3.5">GPT-3.5 (Faster)</option>
              <option value="claude">Claude (Detailed)</option>
            </select>
          </div>

          <div className="setting-item toggle-item">
            <div className="toggle-label">
              <span>Auto-save Summaries</span>
              <small>Automatically save all generated summaries</small>
            </div>
            <label className="toggle-switch">
              <input 
                type="checkbox" 
                checked={settings.autoSave}
                onChange={(e) => handleSettingChange('autoSave', e.target.checked)}
              />
              <span className="slider"></span>
            </label>
          </div>
        </div>

        {/* Appearance */}
        <div className="settings-section">
          <h3>Appearance</h3>
          <div className="setting-item toggle-item">
            <div className="toggle-label">
              <span>Dark Mode</span>
              <small>Switch between light and dark themes</small>
            </div>
            <label className="toggle-switch">
              <input 
                type="checkbox" 
                checked={settings.darkMode}
                onChange={(e) => handleSettingChange('darkMode', e.target.checked)}
              />
              <span className="slider"></span>
            </label>
          </div>

          <div className="setting-item">
            <label>Font Size</label>
            <select>
              <option value="small">Small</option>
              <option value="medium">Medium</option>
              <option value="large">Large</option>
            </select>
          </div>
        </div>

        {/* Notifications */}
        <div className="settings-section">
          <h3>Notifications</h3>
          <div className="setting-item toggle-item">
            <div className="toggle-label">
              <span>Enable Notifications</span>
              <small>Show success and error messages</small>
            </div>
            <label className="toggle-switch">
              <input 
                type="checkbox" 
                checked={settings.notifications}
                onChange={(e) => handleSettingChange('notifications', e.target.checked)}
              />
              <span className="slider"></span>
            </label>
          </div>

          <div className="setting-item toggle-item">
            <div className="toggle-label">
              <span>Completion Sounds</span>
              <small>Play sound when summary is ready</small>
            </div>
            <label className="toggle-switch">
              <input type="checkbox" defaultChecked />
              <span className="slider"></span>
            </label>
          </div>
        </div>

        {/* Data Management */}
        <div className="settings-section">
          <h3>Data Management</h3>
          <div className="setting-item">
            <button className="action-btn export-btn">
              <i className="fas fa-download"></i>
              Export All Data
            </button>
          </div>
          <div className="setting-item">
            <button className="action-btn clear-btn">
              <i className="fas fa-trash"></i>
              Clear Cache
            </button>
          </div>
          <div className="setting-item">
            <button className="action-btn reset-btn" onClick={resetToDefaults}>
              <i className="fas fa-undo"></i>
              Reset to Defaults
            </button>
          </div>
        </div>
      </div>

      <div className="settings-footer">
        <button className="save-btn">Save Changes</button>
        <button className="cancel-btn">Cancel</button>
      </div>
    </div>
  );
};

export default Settings;