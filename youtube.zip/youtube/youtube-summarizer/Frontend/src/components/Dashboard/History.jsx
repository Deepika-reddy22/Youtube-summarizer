import React, { useState, useEffect } from 'react';

const History = () => {
  const [historyItems, setHistoryItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedSummary, setSelectedSummary] = useState(null);

  // Fetch summaries from backend
  useEffect(() => {
    fetchSummaries();
  }, []);

  const fetchSummaries = async () => {
    try {
      const response = await fetch('http://localhost:5000/api/summaries');
      const data = await response.json();
      
      if (data.success) {
        setHistoryItems(data.data || []);
      }
    } catch (error) {
      console.error('Error fetching summaries:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const handleViewFull = (summary) => {
    setSelectedSummary(summary);
  };

  const handleCopy = async (summaryText) => {
    try {
      await navigator.clipboard.writeText(summaryText);
      alert('Summary copied to clipboard!');
    } catch (error) {
      console.error('Failed to copy:', error);
    }
  };

  const handleDelete = async (summaryId) => {
    if (window.confirm('Are you sure you want to delete this summary?')) {
      try {
        const response = await fetch(`http://localhost:5000/api/summaries/${summaryId}`, {
          method: 'DELETE'
        });
        
        if (response.ok) {
          // Remove from local state
          setHistoryItems(prev => prev.filter(item => item.id !== summaryId));
          if (selectedSummary?.id === summaryId) {
            setSelectedSummary(null);
          }
        }
      } catch (error) {
        console.error('Error deleting summary:', error);
      }
    }
  };

  if (loading) {
    return (
      <div className="history-section">
        <h2>Your Summary History</h2>
        <div className="loading">Loading your summaries...</div>
      </div>
    );
  }

  // Detailed view for a single summary
  if (selectedSummary) {
    return (
      <div className="history-section">
        <button 
          className="back-button"
          onClick={() => setSelectedSummary(null)}
        >
          ← Back to History
        </button>
        
        <div className="summary-detail">
          <div className="detail-header">
            <h2>{selectedSummary.videoInfo.title}</h2>
            <p className="channel">{selectedSummary.videoInfo.channel}</p>
          </div>
          
          <div className="video-stats">
            <span>Duration: {selectedSummary.videoInfo.duration}</span>
            <span>Views: {selectedSummary.videoInfo.views}</span>
            <span>Likes: {selectedSummary.videoInfo.likes}</span>
            <span>Summarized: {formatDate(selectedSummary.createdAt)}</span>
          </div>

          <div className="summary-content">
            <h3>Summary</h3>
            <div className="summary-text">
              {selectedSummary.summary.split('\n').map((paragraph, index) => (
                <p key={index}>{paragraph}</p>
              ))}
            </div>
          </div>

          <div className="analytics">
            <h3>Analytics</h3>
            <div className="stats-grid">
              <div className="stat">
                <span className="stat-label">Word Count</span>
                <span className="stat-value">{selectedSummary.analytics.wordCount}</span>
              </div>
              <div className="stat">
                <span className="stat-label">Reading Time</span>
                <span className="stat-value">{selectedSummary.analytics.readingTime} min</span>
              </div>
              <div className="stat">
                <span className="stat-label">Readability</span>
                <span className="stat-value">{Math.round(selectedSummary.analytics.readabilityScore)}%</span>
              </div>
            </div>
          </div>

          <div className="action-buttons">
            <button 
              className="action-btn primary"
              onClick={() => handleCopy(selectedSummary.summary)}
            >
              <i className="fas fa-copy"></i>
              Copy Summary
            </button>
            <button 
              className="action-btn secondary"
              onClick={() => handleDelete(selectedSummary.id)}
            >
              <i className="fas fa-trash"></i>
              Delete
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Main history list view
  return (
    <div className="history-section">
      <h2>Your Summary History</h2>
      <p className="history-subtitle">View and manage your previously generated summaries</p>
      
      <div className="history-list">
        {historyItems.map(item => (
          <div key={item.id} className="history-item">
            <div className="history-item-header">
              <div>
                <h4 className="history-item-title">{item.videoInfo.title}</h4>
                <p className="history-item-channel">{item.videoInfo.channel}</p>
              </div>
              <span className="history-item-date">{formatDate(item.createdAt)}</span>
            </div>
            
            <div className="video-meta">
              <span>⏱️ {item.videoInfo.duration}</span>
              <span>👁️ {item.videoInfo.views} views</span>
              <span>❤️ {item.videoInfo.likes} likes</span>
            </div>
            
            <p className="history-item-summary">
              {item.summary.substring(0, 150)}...
            </p>
            
            <div className="summary-stats">
              <span>📝 {item.analytics.wordCount} words</span>
              <span>⏰ {item.analytics.readingTime} min read</span>
            </div>
            
            <div className="history-item-actions">
              <button 
                className="action-btn"
                onClick={() => handleViewFull(item)}
              >
                <i className="fas fa-eye"></i>
                View Full
              </button>
              <button 
                className="action-btn"
                onClick={() => handleCopy(item.summary)}
              >
                <i className="fas fa-copy"></i>
                Copy
              </button>
              <button 
                className="action-btn"
                onClick={() => handleDelete(item.id)}
              >
                <i className="fas fa-trash"></i>
                Delete
              </button>
            </div>
          </div>
        ))}
      </div>
      
      {historyItems.length === 0 && (
        <div className="empty-state">
          <i className="fas fa-history"></i>
          <h3>No summaries yet</h3>
          <p>Start by summarizing your first YouTube video!</p>
        </div>
      )}
    </div>
  );
};

export default History;