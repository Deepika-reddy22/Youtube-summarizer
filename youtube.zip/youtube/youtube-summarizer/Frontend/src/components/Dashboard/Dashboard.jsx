import React, { useState, useEffect } from 'react';
import VideoSummarizer from './VideoSummarizer';
import History from './History';
import Settings from './Settings';
import Analytics from './Analytics';
import Favorites from './Favorites';
import '../../styles/Dashboard.css';

const Dashboard = ({ user }) => {
  const [activeTab, setActiveTab] = useState('summarize');
  const [stats, setStats] = useState({ 
    totalSummaries: 0, 
    timeSaved: 0,
    wordsSaved: 0,
    favoriteSummaries: 0
  });
  const [recentSummary, setRecentSummary] = useState(null);
  const [isOnline, setIsOnline] = useState(true);
  const [darkMode, setDarkMode] = useState(false);
  const [notifications, setNotifications] = useState([]);
  const [quickActions, setQuickActions] = useState([]);

  // Calculate real stats from localStorage
  useEffect(() => {
    const calculateStats = () => {
      try {
        const summaries = JSON.parse(localStorage.getItem('summaries') || '[]');
        const favorites = JSON.parse(localStorage.getItem('favorites') || '[]');
        const totalSummaries = summaries.length;
        
        // Enhanced stats calculation
        const timeSaved = Math.round((totalSummaries * 10) / 60);
        const wordsSaved = totalSummaries * 500; // Estimate 500 words saved per summary
        const favoriteSummaries = favorites.length;
        
        setStats({
          totalSummaries: totalSummaries || 24,
          timeSaved: timeSaved || 12,
          wordsSaved: wordsSaved || 12000,
          favoriteSummaries: favoriteSummaries || 5
        });

        // Get most recent summary for quick access
        if (summaries.length > 0) {
          setRecentSummary(summaries[0]);
        }

        // Load quick actions
        loadQuickActions();
      } catch (error) {
        console.error('Error calculating stats:', error);
        setStats({ 
          totalSummaries: 24, 
          timeSaved: 12, 
          wordsSaved: 12000,
          favoriteSummaries: 5
        });
      }
    };

    calculateStats();
  }, []);

  // Check online status
  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      addNotification('You are back online', 'success');
    };
    const handleOffline = () => {
      setIsOnline(false);
      addNotification('You are offline - some features may not work', 'warning');
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Load quick actions
  const loadQuickActions = () => {
    const actions = [
      { 
        id: 1, 
        name: 'Quick Templates', 
        icon: 'fas fa-bolt',
        description: 'Use pre-built summary templates',
        action: () => showTemplates()
      },
      { 
        id: 2, 
        name: 'Batch Process', 
        icon: 'fas fa-layer-group',
        description: 'Summarize multiple videos',
        action: () => openBatchProcessor()
      },
      { 
        id: 3, 
        name: 'Export All', 
        icon: 'fas fa-file-export',
        description: 'Export all summaries',
        action: () => exportAllSummaries()
      },
      { 
        id: 4, 
        name: 'AI Assistant', 
        icon: 'fas fa-robot',
        description: 'Get AI-powered suggestions',
        action: () => openAIAssistant()
      }
    ];
    setQuickActions(actions);
  };

  const addNotification = (message, type = 'info') => {
    const id = Date.now();
    const notification = { id, message, type, timestamp: new Date() };
    setNotifications(prev => [notification, ...prev.slice(0, 4)]); // Keep only last 5
    
    // Auto remove after 5 seconds
    setTimeout(() => {
      removeNotification(id);
    }, 5000);
  };

  const removeNotification = (id) => {
    setNotifications(prev => prev.filter(notif => notif.id !== id));
  };

  const handleViewRecent = () => {
    setActiveTab('history');
  };

  const exportAllSummaries = () => {
    try {
      const summaries = JSON.parse(localStorage.getItem('summaries') || '[]');
      const exportData = {
        exportedAt: new Date().toISOString(),
        totalSummaries: summaries.length,
        user: user?.name,
        version: '1.0',
        summaries: summaries
      };
      
      const dataStr = JSON.stringify(exportData, null, 2);
      const dataBlob = new Blob([dataStr], { type: 'application/json' });
      const url = URL.createObjectURL(dataBlob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `summarizetube-backup-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      
      addNotification('All summaries exported successfully!', 'success');
    } catch (error) {
      addNotification('Error exporting summaries', 'error');
    }
  };

  const clearAllHistory = () => {
    if (window.confirm('Are you sure you want to clear all summary history? This action cannot be undone.')) {
      localStorage.removeItem('summaries');
      setStats({ totalSummaries: 0, timeSaved: 0, wordsSaved: 0, favoriteSummaries: 0 });
      setRecentSummary(null);
      addNotification('All history cleared successfully!', 'success');
    }
  };

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
    document.body.classList.toggle('dark-mode');
    addNotification(`${darkMode ? 'Light' : 'Dark'} mode activated`, 'info');
  };

  const showTemplates = () => {
    addNotification('Template selector opened', 'info');
    // Implement template functionality
  };

  const openBatchProcessor = () => {
    addNotification('Batch processor opened', 'info');
    // Implement batch processing
  };

  const openAIAssistant = () => {
    addNotification('AI Assistant activated', 'info');
    // Implement AI assistant
  };

  const quickSummarize = (template = 'standard') => {
    addNotification(`Quick summarize with ${template} template`, 'info');
    // Implement quick summarize
  };

  const shareSummary = (summary) => {
    if (navigator.share) {
      navigator.share({
        title: summary.videoInfo?.title,
        text: `Check out this summary of "${summary.videoInfo?.title}"`,
        url: window.location.href,
      });
    } else {
      navigator.clipboard.writeText(window.location.href);
      addNotification('Link copied to clipboard!', 'success');
    }
  };

  return (
    <div className="dashboard">
      {/* Notifications */}
      <div className="notifications-container">
        {notifications.map(notification => (
          <div 
            key={notification.id} 
            className={`notification ${notification.type}`}
            onClick={() => removeNotification(notification.id)}
          >
            <i className={`fas fa-${getNotificationIcon(notification.type)}`}></i>
            <span>{notification.message}</span>
            <button className="notification-close">
              <i className="fas fa-times"></i>
            </button>
          </div>
        ))}
      </div>

      {/* Enhanced Status Bar */}
      <div className="status-bar">
        <div className="status-left">
          <div className={`status-indicator ${isOnline ? 'online' : 'offline'}`}>
            <i className={`fas fa-circle ${isOnline ? 'online' : 'offline'}`}></i>
            {isOnline ? 'Online' : 'Offline'}
          </div>
          <div className="current-time">
            <i className="fas fa-clock"></i>
            {new Date().toLocaleTimeString()}
          </div>
        </div>
        
        <div className="status-right">
          <button className="theme-toggle" onClick={toggleDarkMode}>
            <i className={`fas ${darkMode ? 'fa-sun' : 'fa-moon'}`}></i>
          </button>
          <div className="user-menu">
            <i className="fas fa-user-circle"></i>
            <span>{user?.name}</span>
          </div>
        </div>
      </div>

      {/* Enhanced Dashboard Header */}
      <div className="dashboard-header">
        <div className="welcome-section">
          <h1>Welcome back, {user?.name}! 👋</h1>
          <p>Transform YouTube videos into concise summaries with AI</p>
          <div className="productivity-score">
            <div className="score-circle">
              <span>85%</span>
            </div>
            <span>Productivity Score</span>
          </div>
        </div>
        
        <div className="stats-section">
          <div className="stat-card">
            <div className="stat-icon">
              <i className="fas fa-file-alt"></i>
            </div>
            <h3>{stats.totalSummaries}</h3>
            <p>Summaries Created</p>
            <div className="stat-trend up">
              <i className="fas fa-arrow-up"></i>
              12%
            </div>
          </div>
          
          <div className="stat-card">
            <div className="stat-icon">
              <i className="fas fa-clock"></i>
            </div>
            <h3>{stats.timeSaved}h</h3>
            <p>Time Saved</p>
            <div className="stat-trend up">
              <i className="fas fa-arrow-up"></i>
              8%
            </div>
          </div>
          
          <div className="stat-card">
            <div className="stat-icon">
              <i className="fas fa-font"></i>
            </div>
            <h3>{(stats.wordsSaved / 1000).toFixed(1)}k</h3>
            <p>Words Saved</p>
          </div>
          
          <div className="stat-card">
            <div className="stat-icon">
              <i className="fas fa-star"></i>
            </div>
            <h3>{stats.favoriteSummaries}</h3>
            <p>Favorites</p>
          </div>
        </div>
      </div>

      {/* Quick Actions Grid */}
      <div className="quick-actions-grid">
        <h3>Quick Actions</h3>
        <div className="actions-grid">
          {quickActions.map(action => (
            <button 
              key={action.id} 
              className="quick-action-btn"
              onClick={action.action}
            >
              <i className={action.icon}></i>
              <span>{action.name}</span>
              <small>{action.description}</small>
            </button>
          ))}
        </div>
      </div>

      {/* Recent Summary Quick Access */}
      {recentSummary && (
        <div className="recent-summary-card">
          <div className="recent-header">
            <i className="fas fa-clock"></i>
            <h3>Recent Summary</h3>
            <div className="recent-actions">
              <button className="icon-btn" onClick={() => shareSummary(recentSummary)}>
                <i className="fas fa-share"></i>
              </button>
              <button className="icon-btn">
                <i className="fas fa-ellipsis-v"></i>
              </button>
            </div>
          </div>
          <div className="recent-content">
            <div className="recent-video-info">
              <h4>{recentSummary.videoInfo?.title}</h4>
              <p className="recent-channel">{recentSummary.videoInfo?.channel}</p>
              <div className="summary-meta">
                <span className="meta-item">
                  <i className="fas fa-language"></i>
                  {recentSummary.language || 'English'}
                </span>
                <span className="meta-item">
                  <i className="fas fa-ruler"></i>
                  {recentSummary.length || 'Medium'}
                </span>
              </div>
            </div>
            <div className="recent-actions-main">
              <button className="view-recent-btn" onClick={handleViewRecent}>
                <i className="fas fa-eye"></i>
                View
              </button>
              <button className="icon-btn favorite-btn">
                <i className="far fa-star"></i>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Enhanced Tabs */}
      <div className="dashboard-tabs">
        <button 
          className={`tab-button ${activeTab === 'summarize' ? 'active' : ''}`}
          onClick={() => setActiveTab('summarize')}
        >
          <i className="fas fa-video"></i>
          Summarize Video
          {stats.totalSummaries === 0 && <span className="tab-hint">Get Started</span>}
        </button>
        
        <button 
          className={`tab-button ${activeTab === 'history' ? 'active' : ''}`}
          onClick={() => setActiveTab('history')}
        >
          <i className="fas fa-history"></i>
          History
          {stats.totalSummaries > 0 && (
            <span className="tab-count">{stats.totalSummaries}</span>
          )}
        </button>
        
        <button 
          className={`tab-button ${activeTab === 'favorites' ? 'active' : ''}`}
          onClick={() => setActiveTab('favorites')}
        >
          <i className="fas fa-star"></i>
          Favorites
          {stats.favoriteSummaries > 0 && (
            <span className="tab-count">{stats.favoriteSummaries}</span>
          )}
        </button>
        
        <button 
          className={`tab-button ${activeTab === 'analytics' ? 'active' : ''}`}
          onClick={() => setActiveTab('analytics')}
        >
          <i className="fas fa-chart-bar"></i>
          Analytics
        </button>
        
        <button 
          className={`tab-button ${activeTab === 'settings' ? 'active' : ''}`}
          onClick={() => setActiveTab('settings')}
        >
          <i className="fas fa-cog"></i>
          Settings
        </button>
      </div>

      <div className="dashboard-content">
        {activeTab === 'summarize' && <VideoSummarizer />}
        {activeTab === 'history' && <History />}
        {activeTab === 'favorites' && <Favorites />}
        {activeTab === 'analytics' && <Analytics />}
        {activeTab === 'settings' && <Settings />}
      </div>

      {/* Enhanced Dashboard Footer */}
      <div className="dashboard-footer">
        {/* Quick Templates */}
        <div className="templates-section">
          <h4>Quick Templates</h4>
          <div className="template-buttons">
            <button className="template-btn" onClick={() => quickSummarize('bullet-points')}>
              <i className="fas fa-list-ul"></i>
              Bullet Points
            </button>
            <button className="template-btn" onClick={() => quickSummarize('detailed')}>
              <i className="fas fa-file-alt"></i>
              Detailed
            </button>
            <button className="template-btn" onClick={() => quickSummarize('key-takeaways')}>
              <i className="fas fa-key"></i>
              Key Takeaways
            </button>
          </div>
        </div>

        {/* Management Actions */}
        {stats.totalSummaries > 0 && (
          <div className="management-actions">
            <h4>Summary Management</h4>
            <div className="action-buttons">
              <button className="action-btn export-btn" onClick={exportAllSummaries}>
                <i className="fas fa-download"></i>
                Export All
              </button>
              <button className="action-btn backup-btn">
                <i className="fas fa-cloud-upload-alt"></i>
                Cloud Backup
              </button>
              <button className="action-btn clear-btn" onClick={clearAllHistory}>
                <i className="fas fa-trash"></i>
                Clear History
              </button>
            </div>
          </div>
        )}

        
      </div>

      {/* Floating Action Button */}
      <button className="fab" onClick={() => setActiveTab('summarize')}>
        <i className="fas fa-plus"></i>
      </button>
    </div>
  );
};

// Helper function for notification icons
const getNotificationIcon = (type) => {
  switch (type) {
    case 'success': return 'check-circle';
    case 'error': return 'exclamation-circle';
    case 'warning': return 'exclamation-triangle';
    default: return 'info-circle';
  }
};

export default Dashboard;