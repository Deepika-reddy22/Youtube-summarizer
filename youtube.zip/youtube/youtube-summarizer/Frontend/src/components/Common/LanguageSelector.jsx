// In your LanguageContext.js
import React, { createContext, useState, useContext } from 'react';

const LanguageContext = createContext();

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};

export const LanguageProvider = ({ children }) => {
  const [currentLanguage, setCurrentLanguage] = useState('english');

  const languages = {
    english: { code: 'english', name: 'English', flag: '🇺🇸' },
    hindi: { code: 'hindi', name: 'Hindi', flag: '🇮🇳' },
    tamil: { code: 'tamil', name: 'Tamil', flag: '🇮🇳' },
    telugu: { code: 'telugu', name: 'Telugu', flag: '🇮🇳' },
    malayalam: { code: 'malayalam', name: 'Malayalam', flag: '🇮🇳' },
    kannada: { code: 'kannada', name: 'Kannada', flag: '🇮🇳' },
    spanish: { code: 'spanish', name: 'Spanish', flag: '🇪🇸' },
    french: { code: 'french', name: 'French', flag: '🇫🇷' },
    german: { code: 'german', name: 'German', flag: '🇩🇪' },
    japanese: { code: 'japanese', name: 'Japanese', flag: '🇯🇵' }
  };

  const changeLanguage = (langCode) => {
    setCurrentLanguage(langCode);
  };

  const value = {
    currentLanguage,
    languages,
    changeLanguage
  };

  return (
    <LanguageContext.Provider value={value}>
      {children}
    </LanguageContext.Provider>
  );
};