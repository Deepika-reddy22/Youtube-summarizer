import React from 'react';
import { Link } from 'react-router-dom';
import ThemeToggle from './ThemeToggle';
import LanguageSelector from './LanguageSelector';
import { useTheme } from '../../contexts/ThemeContext';

const Navbar = ({ isAuthenticated, user, onLogout }) => {
  const { isDarkMode } = useTheme();

  return (
    <nav className="navbar">
      <div className="navbar-content">
        <Link to="/" className="logo">
          <i className="fas fa-play-circle logo-icon"></i>
          <span className="logo-text">Summarize<span>Tube</span></span>
        </Link>
        
        <div className="nav-links">
          <div className="nav-controls">
            <ThemeToggle />
            <LanguageSelector />
          </div>
          
          {isAuthenticated ? (
            <div className="nav-user">
              <div className="user-info">
                <div className="user-name">{user?.name}</div>
                <div className="user-email">{user?.email}</div>
              </div>
              <button onClick={onLogout} className="logout-btn">
                <i className="fas fa-sign-out-alt"></i>
                Logout
              </button>
            </div>
          ) : (
            <div className="nav-auth-buttons">
              <Link to="/login" className="nav-login-btn">
                <i className="fas fa-sign-in-alt"></i>
                <span>Login</span>
              </Link>
              <Link to="/signup" className="nav-signup-btn">
                <i className="fas fa-user-plus"></i>
                <span>Sign Up</span>
              </Link>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;